import { createBrowserRouter } from "react-router-dom";
import React from 'react';

import { Applayout } from "./components/layouts/AppLayout";

import NoMatch from "./pages/NoMatch";
import Book from "./pages/Book";
import Empty from "./pages/Empty";
// import Sample from "./pages/Sample";
import Form from "./pages/Form";
import Confirm from "./pages/Confirm";

import Checkout from "./pages/Checkout";
import Booking from "./pages/Booking";
import Add from "./pages/Add";
import Want from "./pages/Want";
import Search from "./pages/Search";
import Luggage from "./pages/Luggage";
import Verify from "./pages/Verify";
import Confirmation from "./pages/Confirmation";
export const router = createBrowserRouter([
  {
    path: "/",
    element: <Applayout />,
    children: [
      {
        path: "",
        element: <Search />,
      },
      {
        path: "login",
        element: <Verify />,
      },
      {
        path: "confirmation/*",
        element: <Confirmation />
      },
      {
        path: "book",
        element: <Book />,
      },
      {
        path: "luggage",
        element: <Luggage />,
      },
      {
        path: "form",
        element: <Form />,
      },
      {
        path: "confirm",
        element: <Confirm />,
      },
      {
        path: "checkout",
        element: <Checkout />,
      },
      {
        path: "want",
        element: <Want />,
      },
      {
        path: "add",
        element: <Add />,
      },
      {
        path: "booking",
        element: <Booking />,
      },
      {
        path: "empty",
        element: <Empty />,
      },
    ],
  },
  {
    path: "*",
    element: <NoMatch />,
  },
])
