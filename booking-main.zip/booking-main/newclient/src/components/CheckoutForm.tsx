
// import {
//   Card,
//   CardContent,
//   CardDescription,
//   CardFooter,
//   CardHeader,
//   CardTitle,
// } from "../components/ui/card"
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "../components/ui/card"
import React, { useEffect, useState } from "react";
import {
  useStripe,
  useElements,
  PaymentElement,
  PaymentElementProps,
} from "@stripe/react-stripe-js";
import {
  StripeElementsOptions,
  StripePaymentElementOptions,
} from "@stripe/stripe-js";

const CheckoutForm = () => {
  const stripe = useStripe();
  const elements = useElements();
  const [message, setMessage] = useState("");

  const [isLoading, setIsLoading] = useState(false);

  const storedUserData = localStorage.getItem("userData");
  const userData = storedUserData ? JSON.parse(storedUserData) : null;

  useEffect(() => {
    if (!stripe) {
      return;
    }

    const clientSecret = new URLSearchParams(window.location.search).get(
      "payment_intent_client_secret",
    );


    if (!clientSecret) {
      return;
    }

    stripe.retrievePaymentIntent(clientSecret).then(({ paymentIntent }) => {
      if (paymentIntent) {


        switch (paymentIntent.status) {
          case "succeeded":
            setMessage("Payment succeeded!");
            break;
          case "processing":
            setMessage("Your payment is processing.");
            break;
          case "requires_payment_method":
            setMessage("Your payment was not successful, please try again.");
            break;
          default:
            setMessage("Something went wrong.");
            break;
        }
      }
    });
  }, [stripe]);

  const handleSubmit = async (event: { preventDefault: () => void; }) => {
    // We don't want to let default form submission happen here,
    // which would refresh the page.
    event.preventDefault();


    if (!stripe || !elements) {
      // Stripe.js hasn't yet loaded.
      // Make sure to disable form submission until Stripe.js has loaded.
      return;
    }
    setIsLoading(true);

    const { error } = await stripe.confirmPayment({
      //`Elements` instance that was used to create the Payment Element
      elements,
      confirmParams: {
        return_url: `${window.location.origin}/booking`,
      },
    });

    if (error.type === "card_error" || error.type === "validation_error") {
      if (error.message) {

        setMessage(error.message);
      }
    } else {
      setMessage("An unexpected error occurred.");
    }

    setIsLoading(false);
  };

  const paymentElementOptions = {
    layout: "tabs",
  } as StripePaymentElementOptions;
  return (
    <form
      onSubmit={handleSubmit}
      className="bg-white content-center flex-col  rounded-lg shadow-lg p-8 sm:w-max w-[300px] sm:h-max  "
    >
      <h1 className="text-3xl font-semibold mb-6 text-center">Payment </h1>

      {/* <div className="border-t border-gray-300 my-6"></div> */}


      {/* {userData && ( */}
      {/*   <div> */}
      {/*     <h2 className="text-2xl font-semibold mb-4">Booking Details</h2> */}
      {/*     <div className="flex flex-row"> */}
      {/*       <div className="flex mb-2 mr-2"> */}
      {/*         <strong className="w-32">Destination:</strong> */}
      {/*         <span>{userData.destination}</span> */}
      {/*       </div> */}
      {/*       <div className="flex mb-2"> */}
      {/*         <strong className="w-32">Departure:</strong> */}
      {/*         <span>{userData.departure}</span> */}
      {/*       </div> */}
      {/*     </div> */}
      {/**/}
      {/*     <div className="flex flex-row"> */}
      {/*       <div className="flex mb-2 mr-2"> */}
      {/*         <strong className="w-32">Price:</strong> */}
      {/*         <span>${userData.price}</span> */}
      {/*       </div> */}
      {/*       <div className="flex"> */}
      {/*         <strong className="w-32">Passengers:</strong> */}
      {/*         <span>{userData.passengersNo}</span> */}
      {/*       </div> */}
      {/*     </div> */}
      {/*   </div> */}
      {/* )} */}

      <div className="border-t border-gray-300 my-6"></div>

      <PaymentElement options={paymentElementOptions} />

      <button
        disabled={isLoading || !stripe || !elements}
        id="submit"
        className="bg-green-500 text-white py-2 px-4 rounded cursor-pointer mt-10 block mx-auto"
      >
        <span id="button-text">
          {isLoading ? (
            "Processing..."
          ) : (

            "Pay now"
          )}
        </span>
      </button>

      {message && <div className="text-red-600 mt-4">{message}</div>}
    </form>
  );
};
export default CheckoutForm;
