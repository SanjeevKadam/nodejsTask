
import { Label } from "@radix-ui/react-label";
import React, { useEffect, useState } from "react";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { useRecoilState } from "recoil";
import { DAYS } from "../config";
import {
  departdateState,
  departureFromState,
  destinationState,
  returndateState,
  tripTypeState,
} from "../store/home_store";
import { Button } from "./ui/button";
import { CardFooter } from "./ui/card";

import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../components/ui/select"
import { is48HoursAheadDate } from "../lib/utils";
const TRIP_TYPES = {
  ONE_WAY: "one-way",
  ROUND_TRIP: "round-trip",
};

const DestinationOptions = {
  // "": "Choose a Destination",
  POS: "Trinidad & Tobago (POS)",
  YYZ: "Toronto (YYZ)",
};

const Monday = () => {
  const [startDate, setStartDate] = useRecoilState(departdateState);
  const [returnDate, setReturnDate] = useRecoilState(returndateState);
  const [tripType, setTripType] = useRecoilState(tripTypeState);
  const [destination, setDestination] = useRecoilState(destinationState);
  const [departureFrom, setDepartureFrom] = useRecoilState(departureFromState);

  const day = "Monday";
  const { MONDAY } = DAYS;

  const navigate = useNavigate();

  useEffect(() => {
    if (destination === "POS") {
      setDepartureFrom("YYZ");
    } else if (destination === "YYZ") {
      setDepartureFrom("POS");
    } else {
      setDepartureFrom("");
    }
  }, [destination, setDepartureFrom]);

  const fromDestination =
    destination === "POS"
      ? "Toronto (YYZ)"
      : destination === "YYZ"
        ? "Trinidad & Tobago (POS)"
        : "Please pick Destination";

  const isMondayAndFutureDate = (date: Date) => {
    const isMonday = date.getDay() === MONDAY;
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const isFutureDate = date > today;
    return isMonday && isFutureDate;
  };

  const isSameDate = (date1: Date, date2: Date) =>
    date1.toDateString() === date2.toDateString();

  const is48HoursAhead = (date1: Date | null, date2: Date | null) => {
    if (date1 && date2) {

      const timeDifference = date2.getTime() - date1.getTime();
      const hoursDifference = timeDifference / (1000 * 3600);
      return hoursDifference >= 48;
    };
  }

  const handleDepartureDateChange = (date: Date) => {
    if (!isMondayAndFutureDate(date)) {
      toast.error(`Please select a ${day} date in the future.`);
      return;
    }

    if (!is48HoursAhead(new Date(), date)) {
      toast.error("Please book your flight at least 48 hours in advance.");
      return;
    }

    if (returnDate && returnDate < date) {
      setReturnDate(null);
    }

    const parsedDate = new Date(date);
    setStartDate(parsedDate);
  };


  const handleBookNow = () => {


    if (!startDate) {
      toast.error("Please select a departure date before booking.");
      return;
    }

    if (destination === "") {
      toast.error("Please select a Destination before booking.");
      return;
    }

    if (tripType === TRIP_TYPES.ROUND_TRIP && !returnDate) {
      toast.error(
        "Please select a return date before booking for a round trip.",
      );
      return;
    }

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    if (
      !is48HoursAhead(today, startDate) ||
      (tripType === TRIP_TYPES.ROUND_TRIP && !is48HoursAhead(today, returnDate))
    ) {
      toast.error(
        "Please book at least 48 hours ahead for both departure and return.",
      );
      return;
    }

    navigate("/form");
  };

  return (

    <div className=" space-y-4">
      <div className="mb-6">
        <Label>Departure Date:</Label> <br />
        <DatePicker
          showIcon
          selected={startDate}
          onChange={(date: Date) => handleDepartureDateChange(date)}
          filterDate={(date: Date) => date.getDay() === MONDAY && date > new Date() && is48HoursAheadDate(date)}
          // filterTime={(date: Date) => is48HoursAhead(date, new Date())}
          placeholderText="Pick a Departure Date"
          dateFormat="dd/MM/yyyy"
          className="w-full border text-m rounded-md px-3 py-2 mt-1 text-gray-800" // Adjusted width to 100%
        />
      </div>

      <div className="mb-4">
        <Label>Select Your Destination:</Label>
        <Select onValueChange={(value) => setDestination(value)} value={destination} >
          <SelectTrigger id="destination">
            <SelectValue placeholder="Select Destination" />
          </SelectTrigger>
          <SelectContent position="popper" className="border rounded-md mt-1">
            <SelectItem value="POS">Trinidad & Tobago (POS) </SelectItem>
            <SelectItem value="YYZ">Toronto (YYZ)</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="mb-4">
        <Label>Flying From: </Label>
        <span className="text-red-800 font-semibold">{fromDestination}</span>
      </div>

      <CardFooter className="flex justify-center">
        <Button type="button" className=" py-6" onClick={handleBookNow}>
          Book Now
        </Button>
      </CardFooter>
    </div>



  );
};

export default Monday;
