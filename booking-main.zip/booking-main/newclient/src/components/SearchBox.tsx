import React, { useState } from 'react';
import { Label } from './ui/label';
import { CalendarDays, PlaneLanding, PlaneTakeoff, Receipt } from 'lucide-react'
import { Select, SelectGroup, SelectContent, SelectItem, SelectLabel, SelectTrigger, SelectValue } from './ui/select';
import { Button } from './ui/button';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { fadeIn } from '../variants';

const SearchBox = () => {
  const navigate = useNavigate();
  const destinationsToDaysMap = [

    { route: "MBJ-HAV", day: "Tuesday", cost: 300 },
    { route: "HAV-GEO", day: "Tuesday", cost: 720 },
    { route: "HAV-POS", day: "Tuesday", cost: 680 },
    { route: "POS-GEO", day: "Tuesday", cost: 300 },


    { route: "GEO-POS", day: "Wednesday", cost: 300 },
    { route: "POS-HAV", day: "Wednesday", cost: 680 },
    { route: "GEO-HAV", day: "Wednesday", cost: 720 },
    { route: "HAV-MBJ", day: "Wednesday", cost: 300 },

  ];

  const handleSearch = (origin: React.SetStateAction<string>, destination: React.SetStateAction<string>) => {
    const route = `${origin}-${destination}`;
    const matches = destinationsToDaysMap.filter(entry => entry.route === route);
    if (matches.length > 0) {
      return {
        departureDays: matches.map(match => match.day),
        flightCost: matches[0].cost, // Assuming the cost is the same for all matches
      };
    } else {
      return {
        departureDays: ["No flights available for this route"],
        flightCost: 0,
      };
    }
  };

  const [origin, setOrigin] = useState("");
  const [destination, setDestination] = useState("");
  const [departureDays, setDepartureDays] = useState([]) as any;
  const [flightCost, setFlightCost] = useState(0);

  const handleDestinationChange = (value: React.SetStateAction<string>) => {
    setDestination(value);
    const { departureDays, flightCost } = handleSearch(origin, value);
    setDepartureDays(departureDays);
    setFlightCost(flightCost);
  };

  const handleOriginChange = (value: React.SetStateAction<string>) => {
    setOrigin(value);
    const { departureDays, flightCost } = handleSearch(value, destination);
    setDepartureDays(departureDays);
    setFlightCost(flightCost);
  };

  return (
    <motion.div
      variants={fadeIn('down', 0.1)}
      initial='hidden'
      whileInView={'show'}
      viewport={{ once: false, amount: 0 }}
    >
      <div className='w-full  sm:w-[600px] bg-white max-h-max border border-outline rounded-[20px] p-10'>
        <div className='my-4 flex items-center'>
          <PlaneTakeoff size={24} className="mr-2" /> {/* Icon for departure */}
          <Label htmlFor='origin'>Where are you going from?</Label>
        </div>
        <Select onValueChange={handleOriginChange}>
          <SelectTrigger>
            <SelectValue placeholder='origin' />
          </SelectTrigger>
          <SelectContent>
            <SelectGroup>
              <SelectLabel>Origin</SelectLabel>
              {/* <SelectItem value='POS'>POS</SelectItem> */}
              {/* <SelectItem value='YYZ'>YYZ</SelectItem> */}
              {/* <SelectItem value='MIA'>MIA</SelectItem> */}
              {/* <SelectItem value='GUY'>GUY</SelectItem> */}
              {/* <SelectItem value='HAV'>HAV</SelectItem> */}
              {/* <SelectItem value='JAM'>JAM</SelectItem> */}

              <SelectItem value='MBJ'>Jamaica (MBJ)</SelectItem>
              <SelectItem value='HAV'>Cuba (HAV)</SelectItem>
              <SelectItem value='GEO'>Guyana (GEO)</SelectItem>
              <SelectItem value='POS'>Trinidad (POS)</SelectItem>
            </SelectGroup>
          </SelectContent>
        </Select>
        <div className='my-4 flex items-center'>
          <PlaneLanding size={24} className="mr-2" /> {/* Icon for arrival */}
          <Label htmlFor='destination'>Where are you going?</Label>
        </div>
        <Select onValueChange={handleDestinationChange}>
          <SelectTrigger>
            <SelectValue placeholder='destination' />
          </SelectTrigger>
          <SelectContent>
            <SelectGroup>
              <SelectLabel>Destination</SelectLabel>
              {/* <SelectItem value='POS'>POS</SelectItem> */}
              {/* <SelectItem value='YYZ'>YYZ</SelectItem> */}
              {/* <SelectItem value='MIA'>MIA</SelectItem> */}
              {/* <SelectItem value='GUY'>GUY</SelectItem> */}
              {/* <SelectItem value='HAV'>HAV</SelectItem> */}
              {/* <SelectItem value='JAM'>JAM</SelectItem> */}

              <SelectItem value='MBJ'>Jamaica (MBJ)</SelectItem>
              <SelectItem value='HAV'>Cuba (HAV)</SelectItem>
              <SelectItem value='GEO'>Guyana (GEO)</SelectItem>
              <SelectItem value='POS'>Trinidad (POS)</SelectItem>
            </SelectGroup>
          </SelectContent>
        </Select>
        <div className='mt-8'>
          <div className='flex items-center mb-4'>
            <CalendarDays className="mr-2 h-12 w-12 sm:h-8 sm:w-8" /> {/* Icon for departure day */}
            <p><span className="font-bold">Departure Day :</span> {departureDays.length > 0 ? departureDays.join(", ") : " Please Select Destination and Departure"}</p>
          </div>
          <div className='flex items-center'>
            <Receipt className="mr-2 h-12 w-12 sm:h-8 sm:w-8" /> {/* Icon for flight cost */}

            {
              destination === "" || origin === "" ?

                <p><span className="font-bold">Estimated Cost :</span> Please Select Destination and Departure </p> : <p><span className="font-bold">Flight Cost:</span> {flightCost ? `$${flightCost} per passenger` : "No Flight available"}</p>
            }
            {/* <p><span className="font-bold">Flight Cost:</span> {flightCost ? `Will cost around $${flightCost} per passenger` : "No Flight available"}</p> */}
          </div>
        </div>
        {/* {departureDays[0] !== "No flights available for this route" ? */}
        <div className="flex justify-center">
          <Button size='lg' variant='default' onClick={() => { navigate('/book') }} className='mt-6'>
            Book Now
          </Button>
        </div>
        {/*   : */}
        {/*   <></> */}
        {/* } */}
      </div>
    </motion.div>
  );
};

export default SearchBox;
