import { Label } from "@radix-ui/react-label";
import React, { useEffect } from "react";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { useRecoilState } from "recoil";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "../components/ui/select";
import { DAYS } from "../config";
import { is48HoursAheadDate } from "../lib/utils";
import {
  departdateState,
  departureFromState,
  destinationState
} from "../store/home_store";
import { Button } from "./ui/button";
import { CardFooter } from "./ui/card";

// Mia > Hav > Guy > Mia

// const DestinationOptions = {
//   // "": "Choose a Destination",
//   MIA: "Miami (MIA)",
//   HAV: "Havana (HAV)",
//   GUY: "Guyana (GUY)",
//   JAM: "Jamaica (JAM)",
// };
const DestinationOptions = {
  // "": "Choose a Destination",
  GEO: "Guyana (GEO)",
  HAV: "Cuba (HAV)",
  POS: "Trinidad (POS)",
  // TAB: "Tobago(TAB)"
};

const DepartureOptions = {
  // "": "Choose a Destination",
  // GEO: "Guyana (GEO)",
  HAV: "Cuba (HAV)",
  POS: "Trinidad (POS)",
  // TAB: "Tobago(TAB)"
};
const Tuesday = () => {
  const [startDate, setStartDate] = useRecoilState(departdateState);
  const [destination, setDestination] = useRecoilState(destinationState);
  const [departureFrom, setDepartureFrom] = useRecoilState(departureFromState);

  const navigate = useNavigate();

  useEffect(() => {
    if (destination === "HAV") {
      setDepartureFrom("MBJ");
    } else if (destination === "POS") {
      setDepartureFrom("HAV");
    }
  }, [destination]);

  let from = "";
  if (departureFrom === "MBJ") {
    from = "Jamaica (MBJ)";
  } else if (departureFrom === "HAV") {
    from = "Cuba (HAV)";
  } else if (departureFrom === "POS") {
    from = "Tobago (POS)";
  } else {
    from = "Please pick Destination";
  }

  const isTuesdayAndFutureDate = (date: Date) => {
    const isMonday = date.getDay() === DAYS.TUESDAY;
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const isFutureDate = date > today;
    return isMonday && isFutureDate;
  };

  const is48HoursAhead = (date1: Date, date2: Date) => {
    const timeDifference = date2.getTime() - date1.getTime();
    const hoursDifference = timeDifference / (1000 * 3600);
    return hoursDifference >= 48;
  };

  const handleDepartureDateChange = (date: Date) => {
    if (date != null) {
      if (!isTuesdayAndFutureDate(date)) {
        toast.error("Please select a Tuesday date in the future.");
        return;
      }

      if (!is48HoursAhead(new Date(), date)) {
        toast.error("Please book your flight at least 48 hours in advance.");
        return;
      }
    }
    setStartDate(date);
  };

  const handleBookNow = () => {
    console.log(destination, departureFrom,)
    if (!startDate) {

      toast.error("Please select a departure date before booking.");
      return;
    }

    if (destination === "") {
      toast.error("Please select a Destination before booking.");
      return;
    }

    if (departureFrom === "") {
      toast.error("Please select a Departure before booking.");
      return;
    }

    if (startDate.getMonth() === 1) {
      toast.error("Sorry, Flight not available");
      return;
    }

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    if (!is48HoursAhead(today, startDate)) {
      toast.error("Please book at least 48 hours ahead for both departure and return.");
      return;
    }

    navigate("/form");
  };

  const OnchangeDestination = (value: string) => {
    setDestination("");
    setDestination(value);
    setDepartureFrom("")
  }
  const OnchangeDepartureFrom = (value: string) => {
    setDepartureFrom("");
    setDepartureFrom(value);
  }

  return (
    <div className=" space-y-4">
      <div className="mb-6">
        <Label>Departure Date:</Label> <br />
        <DatePicker
          showIcon
          selected={startDate}
          onChange={(date: Date) => handleDepartureDateChange(date)}
          filterDate={(date) =>
            date.getDay() === DAYS.TUESDAY && date > new Date()
            && is48HoursAheadDate(date)
            && date.getMonth() !== 1
          }
          placeholderText="Pick a Departure Date"
          dateFormat="dd/MM/yyyy"
          className="w-full border text-m rounded-md px-3 py-2 mt-1 text-gray-800"
        />
      </div>

      <div className="mb-6">
        <Label>Select Your Destination:</Label>
        <Select onValueChange={(value) => OnchangeDestination(value)} value={destination} >
          <SelectTrigger id="destination">
            <SelectValue placeholder="Select Destination" />
          </SelectTrigger>
          <SelectContent position="popper" className="border rounded-md mt-1">
            {Object.entries(DestinationOptions).map(([value, Label]) => (
              <SelectItem key={value} value={value}>{Label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {destination === "GEO" ?

        <div className="mb-6">
          <Label>Select Your Departure:</Label>
          <Select onValueChange={(value) => OnchangeDepartureFrom(value)} value={departureFrom} >
            <SelectTrigger id="departure">
              <SelectValue placeholder="Select Departure" />
            </SelectTrigger>
            <SelectContent position="popper" className="border rounded-md mt-1">
              {Object.entries(DepartureOptions).map(([value, Label]) => (
                <SelectItem key={value} value={value}>{Label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        :

        <div className="mb-4">
          <Label>Flying From: </Label>
          <span className="text-red-800 font-semibold">{from}</span>
        </div>
      }
      <CardFooter className="flex justify-center">
        <Button type="button" className=" py-6" onClick={handleBookNow}>
          Book Now
        </Button>
      </CardFooter>
    </div>
  );
};

export default Tuesday;
