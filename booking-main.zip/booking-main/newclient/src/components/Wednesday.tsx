import React, { useEffect } from "react";
import { Button } from "./ui/button";
import { CardFooter } from "./ui/card";
import { Label } from "@radix-ui/react-label";


import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "../components/ui/select";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { useRecoilState } from "recoil";
import { DAYS } from "../config";
import {
  departdateState,
  departureFromState,
  destinationState,
} from "../store/home_store";
import { is48HoursAheadDate } from "../lib/utils";

// mia > pos > mia > Guy > mia
//  Mia  >> Pos
//  POS ,Guy  >> Mia
//  Mia > GUY
//
// const DestinationOptions = {
//   // MIA: "Miami (MIA)",
// POS: "Trinidad & Tobago (POS)",
// GUY: "Guyana (GUY)",
// };

const DestinationOptions = {
  // MIA: "Miami (MIA)",
  POS: "Trinidad (POS)",
  HAV: "Cuba (HAV)",
  MBJ: "Jamaica (MBJ)",

  // TAB: "Tobago (TAB)",
};


const DepartureOptions = {
  POS: "Trinidad (POS)",
  GUY: "Guyana (GEO)",
};

const Wednesday = () => {
  const [startDate, setStartDate] = useRecoilState(departdateState);
  const [destination, setDestination] = useRecoilState(destinationState);
  const [departureFrom, setDepartureFrom] = useRecoilState(departureFromState);

  const navigate = useNavigate();

  // useEffect(() => {
  //   if (destination === "POS") {
  //     setDepartureFrom("MIA");
  //   } else if (destination === "GUY") {
  //     setDepartureFrom("MIA");
  //   }
  // }, [destination, setDepartureFrom]);
  //
  // let from = "";
  // if (departureFrom === "MIA") {
  //   from = "Miami (MIA)";
  // } else if (departureFrom === "POS") {
  //   from = "Trinidad & Tobago (POS)";
  // } else if (departureFrom === "GUY") {
  //   from = "Guyana (GUY)";
  // } else {
  //   from = "Please pick Destination";
  // }

  useEffect(() => {
    if (destination === "POS") {
      setDepartureFrom("GEO");
    } else if (destination === "MBJ") {
      setDepartureFrom("HAV");
    }
  }, [destination]);

  let from = "";
  if (departureFrom === "GEO") {
    from = "Guyana (GEO)";
  } else if (departureFrom === "POS") {
    from = "Trinidad (POS)";
  } else if (departureFrom === "HAV") {
    from = "Cuba (HAV)";
  } else {
    from = "Please pick Destination";
  }
  const isWednesdayAndFutureDate = (date: Date) => {
    const isWednesday = date.getDay() === DAYS.WEDNESDAY;
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const isFutureDate = date > today;
    return isWednesday && isFutureDate;
  };

  const is48HoursAhead = (date1: Date, date2: Date) => {
    const timeDifference = date2.getTime() - date1.getTime();
    const hoursDifference = timeDifference / (1000 * 3600);
    return hoursDifference >= 48;
  };

  const handleDepartureDateChange = (date: Date | null) => {
    if (date) {


      if (!isWednesdayAndFutureDate(date)) {
        toast.error("Please select a Wednesday date in the future.");
        return;
      }

      if (!is48HoursAhead(new Date(), date)) {
        toast.error("Please book your flight at least 48 hours in advance.");
        return;
      }
    }
    setStartDate(date);
  };

  const handleBookNow = () => {
    if (!startDate) {
      toast.error("Please select a departure date before booking.");
      return;
    }

    if (destination === "") {
      toast.error("Please select a Destination before booking.");
      return;
    }

    if (departureFrom === "") {
      toast.error("Please select a Departure before booking.");
      return;
    }
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    if (startDate.getMonth() === 1) {

      toast.error("Sorry Flight not available");
      return;
    }
    if (!is48HoursAhead(today, startDate)) {
      toast.error(
        "Please book at least 48 hours ahead for both departure and return.",
      );
      return;
    }

    navigate("/form");
  };

  const OnchangeDestination = (value: string) => {
    setDestination("");
    setDestination(value);
    setDepartureFrom("")
  }
  const OnchangeDepartureFrom = (value: string) => {
    setDepartureFrom("");
    setDepartureFrom(value);
  }

  return (
    <div className=" space-y-4">
      <div className="mb-6">
        <Label>Departure Date:</Label> <br />
        <DatePicker
          showIcon
          selected={startDate}
          onChange={(date) => handleDepartureDateChange(date)}
          filterDate={(date) =>
            date.getDay() === DAYS.WEDNESDAY && date > new Date()
            && is48HoursAheadDate(date)
            && date.getMonth() !== 1
          }
          placeholderText="Pick a Departure Date"
          dateFormat="dd/MM/yyyy"
          className="w-full border text-m rounded-md px-3 py-2 mt-1 text-gray-800"
        />

      </div>
      <div className="mb-6">
        <Label>Select Your Destination:</Label>
        <Select onValueChange={(value) => OnchangeDestination(value)} value={destination} >
          <SelectTrigger id="destination">
            <SelectValue placeholder="Select Destination" />
          </SelectTrigger>
          <SelectContent position="popper" className="border rounded-md mt-1">
            {Object.entries(DestinationOptions).map(([value, Label]) => (
              <SelectItem value={value}>{Label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>





      {destination === "HAV" ?

        <div className="mb-6">
          <Label>Select Your Departure:</Label>
          <Select onValueChange={(value) => OnchangeDepartureFrom(value)} value={departureFrom} >
            <SelectTrigger id="departure">
              <SelectValue placeholder="Select Departure" />
            </SelectTrigger>
            <SelectContent position="popper" className="border rounded-md mt-1">
              {Object.entries(DepartureOptions).map(([value, Label]) => (
                <SelectItem key={value} value={value}>{Label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        :

        <div className="mb-4">
          <Label>Flying From: </Label>
          <span className="text-red-800 font-semibold">{from}</span>
        </div>
      }


      <CardFooter className="flex justify-center">
        <Button type="button" className=" py-6" onClick={handleBookNow}>
          Book Now
        </Button>
      </CardFooter>
    </div>
  );
};

export default Wednesday;
