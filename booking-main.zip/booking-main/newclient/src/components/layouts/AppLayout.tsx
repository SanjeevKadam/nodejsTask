import { Outlet } from "react-router-dom";
import { Header } from "./Header";
import { Footer } from "./Footer";

export function Applayout() {

  const getRandomPosition = () => {
    const top = Math.random() * 80 + 10 + '%'; // Adjusted to keep within 10% - 90% of the screen height
    const left = Math.random() * 80 + 10 + '%'; // Adjusted to keep within 10% - 90% of the screen width
    return { top, left };
  };
  return (
    <>
      <Header />
      <div className="flex-grow flex flex-col">
        <div className="container px-4 md:px-8 flex-grow flex flex-col bg-white-100">

          <div className="bg-gray-50  flex items-center justify-center px-16">
            <div className="relative w-full max-w-lg">
              <div className="absolute w-72 h-72" style={{ ...getRandomPosition() }}>
                <div className="w-full h-full bg-purple-300 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob"></div>
              </div>
              <div className="absolute w-72 h-72" style={{ ...getRandomPosition() }}>
                <div className="w-full h-full bg-yellow-300 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-2000"></div>
              </div>
              <div className="absolute w-72 h-72" style={{ ...getRandomPosition() }}>
                <div className="w-full h-full bg-pink-300 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-4000"></div>
              </div>
              <div className="absolute w-72 h-72" style={{ ...getRandomPosition() }}>
                <div className="w-full h-full bg-pink-300 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-4000"></div>
              </div>
              <div className="absolute w-72 h-72" style={{ ...getRandomPosition() }}>
                <div className="w-full h-full bg-pink-300 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-2000"></div>
              </div>
              <div className="m-8 relative space-y-4">


                <Outlet />

              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="container px-4 md:px-8">
        <Footer />
      </div>
    </>
  )
}
