import { userBookingState } from "../store/user_store";
import React, { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import { useRecoilValue } from "recoil";
import { Button } from "./ui/button";

export const PrintButton = () => {
  const bookings = useRecoilValue(userBookingState)
  const location = useLocation();
  const [shouldRenderButton, setShouldRenderButton] = useState(false);

  useEffect(() => {
    if (location.pathname === "/booking" && bookings.length > 0) {
      setShouldRenderButton(true);
    } else {
      setShouldRenderButton(false);
    }
  }, [location.pathname, bookings]);

  return shouldRenderButton ? (
    <Button
      className="text-center text-white text-lg font-bold font-['Inter'] leading-[15.17px] bg-red-600 px-6 py-3 rounded"
      onClick={() => window.print()}
    >
      PRINT NOW
    </Button>
  ) : (
    <></>
  );
};
