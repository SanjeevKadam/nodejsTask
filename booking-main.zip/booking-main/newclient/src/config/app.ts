interface AppConfig {
  name: string,
  github: {
    title: string,
    url: string
  },
  author: {
    name: string,
    url: string
  },
}

export const appConfig: AppConfig = {
  name: "Umoja Airways",
  github: {
    title: "Umoja Airways",
    url: "",
  },
  author: {
    name: "vipin",
    url: "",
  }
}
