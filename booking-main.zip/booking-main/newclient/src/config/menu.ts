import { Icons } from "../components/icons"
import isAuth from "../hooks/isAuth"
import { useNavigate } from "react-router-dom"

interface NaREACT_APPm {
  title: string
  to?: string
  href?: string
  disabled?: boolean
  external?: boolean
  icon?: keyof typeof Icons
  label?: string
}

interface NaREACT_APPmWithChildren extends NaREACT_APPm {
  items?: NaREACT_APPmWithChildren[]
}


export let mainMenu: NaREACT_APPmWithChildren[] = [
  {
    title: 'Find a Flight',
    to: '',
  },
  {
    title: 'Book Now',
    to: '/book',
  },
  {
    title: 'My booking',
    to: '/booking',
  },
]


export const sideMenu: NaREACT_APPmWithChildren[] = []
