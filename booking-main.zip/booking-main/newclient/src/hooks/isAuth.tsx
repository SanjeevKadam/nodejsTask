import { toast } from "react-toastify";
import { userEmailState } from "../store/user_store";
import { useNavigate } from "react-router-dom";

const isAuth = async () => {
  try {
    const token = localStorage.getItem('token');
    if (!token) {
      throw new Error('Token not found');
    }

    const response = await fetch(`${process.env.REACT_APP_SERVER}/confirm`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      throw new Error('Unauthorized');
    }

    const data = await response.json();
    if (data.email) {
      console.log('auth')
      return true;
    } else {
      console.log('un auth')
      return false;
    }
  } catch (error: any) {
    // toast.error(error.message);
    // window.location.href = "login"
    // throw error; // Rethrow the error for handling in the component
    return false;
    //
  }
};

export default isAuth;
