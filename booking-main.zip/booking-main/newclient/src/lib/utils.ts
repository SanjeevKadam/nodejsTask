import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}



export const is48HoursAheadDate = (date: Date) => {
  const now = new Date();
  const futureDate = new Date(now.getTime() + 48 * 60 * 60 * 1000);
  return date > futureDate;
};


export const isOldEnough = (date: Date): boolean => {
  const today = new Date();
  const eighteenYearsAgo = new Date(today.getFullYear() - 18, today.getMonth(), today.getDate());

  return date <= eighteenYearsAgo;
};
