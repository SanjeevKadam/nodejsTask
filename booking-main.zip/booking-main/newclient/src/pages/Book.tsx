import { PageHeader, PageHeaderHeading } from "../components/page-header";
import Tuesday from "../components/Tuesday";
import Wednesday from "../components/Wednesday";
import Thursday from "../components/Thursday";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";


import Monday from "../components/Monday";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle
} from "../components/ui/card";
import { Label } from "../components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "../components/ui/select";
import { tripOneState } from "../store/home_store";
import { useRecoilState } from "recoil";
import { useEffect } from "react";
import { toast } from "react-toastify";
import { userEmailState } from "../store/user_store";
import { useNavigate } from "react-router-dom";
import isAuth from "../hooks/isAuth";
import { departdateState } from "../store/home_store";
import { destinationState } from "../store/home_store";
import { departureFromState } from "../store/home_store";
import { motion } from "framer-motion";
import { fadeIn } from "../variants";
const formSchema = z.object({
  username: z.string().min(2).max(50),
})
export default function Book() {
  const navigate = useNavigate()
  const [tripon, setTripon] = useRecoilState(tripOneState);
  const [email, setEmail] = useRecoilState(userEmailState);

  const [startDate, setStartDate] = useRecoilState(departdateState);
  const [destination, setDestination] = useRecoilState(destinationState);
  const [departureFrom, setDepartureFrom] = useRecoilState(departureFromState);

  // isAuth();
  useEffect(() => {
    isAuth()
      .then(auth => {
        // Handle successful authentication
        if (!auth) {
          navigate('/login')
        }
        // console.log('Logged in as:', auth);
      })
      .catch(error => {
        // Handle authentication error
        console.error('Authentication error:', error);
      });
  }, []);

  // 2. Define a submit handler.
  function onSubmit(values: z.infer<typeof formSchema>) {
    // Do something with the form values.
    // ✅ This will be type-safe and validated.
    console.log(values)
  }
  console.log(tripon)
  let selectedComponent;

  switch (tripon) {
    // case "monday":
    //   selectedComponent = <Monday />;
    //   break;
    case "tuesday":
      selectedComponent = <Tuesday />;
      break;
    case "wednesday":
      selectedComponent = <Wednesday />;
      break;
    // case "thursday":
    //   selectedComponent = <Thursday />;
    //   break;
    default:
      selectedComponent = null;
  }
  const handleChange = (value: any) => {
    setTripon(value);
    setStartDate(null)
    setDestination("")
    setDepartureFrom("")
  }

  return (

    <section className='flex min-h-screen flex-col items-center justify-center p-4 sm:p-8 md:p-12 lg:p-16 xl:p-24'> {/* Centering vertically and horizontally */}
      <h1 className="text-2xl font-extrabold tracking-tight sm:text-nowrap lg:text-3xl mb-8"> {/* Increase font size and add bottom margin */}
        Thank you for selecting Umoja Airways!
      </h1>

      <motion.div
        variants={fadeIn('down', 0.1)}
        initial='hidden'
        whileInView={'show'}
        viewport={{ once: false, amount: 0 }}

      >
        <div className="flex items-center justify-center m-auto mt-5">
          <div>
            <PageHeader>
              {/* <PageHeaderHeading>Welcome to UmojAirways </PageHeaderHeading> */}
            </PageHeader>
            <Card className="w-[350px] lg:w-[650px] md:w-[450px]" >
              <CardHeader>
                <CardTitle>Book a Flight</CardTitle>
                {/* <CardDescription>Book </CardDescription> */}
              </CardHeader>
              <CardContent>
                <form>
                  <div className="grid w-full items-center gap-4  p-4">
                    <div className="flex flex-col space-y-1.5">
                      <div className="mb-4">
                        <Label htmlFor="day">Available flights </Label>
                        <Select onValueChange={handleChange} value={tripon}  >
                          <SelectTrigger id="day">
                            <SelectValue placeholder="Select" />
                          </SelectTrigger>
                          <SelectContent position="popper">
                            {/* <SelectItem value="monday">Monday</SelectItem> */}
                            <SelectItem value="tuesday">Tuesday</SelectItem>
                            <SelectItem value="wednesday">Wednesday</SelectItem>
                            {/* <SelectItem value="thursday">Thursday</SelectItem> */}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="transition-all duration-300 ease-in-out">
                        {selectedComponent}
                      </div>
                    </div>
                  </div>
                </form>
              </CardContent>
              <CardFooter className="flex justify-end">
                {/* <Button>Book Now</Button> */}
              </CardFooter>
            </Card>
          </div>
        </div >
      </motion.div >
    </section>

  )
}
