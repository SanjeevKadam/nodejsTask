import React, { useEffect, useState } from "react";
import "react-responsive-carousel/lib/styles/carousel.min.css"; // requires a loader
import { Carousel } from 'react-responsive-carousel';
import { toast } from "react-toastify";
import axios from "axios";
import { Alert, AlertDescription, AlertTitle } from "../components/ui/alert";
import { Terminal } from "lucide-react";
import { useStripe } from "@stripe/react-stripe-js";
import { useNavigate } from "react-router-dom";
import isAuth from "../hooks/isAuth";
import { useRecoilState } from "recoil";
import { userBookingState } from "../store/user_store";
import { async } from "q";

export interface BookingDetails {
  firstName: string;
  lastName: string;
  dob: Date;
  address: string;
  email: string;
  phone: string;
  imageURL: string;
  passengers: any[];
  passengersNo: number;
  departdate: Date;
  returndate: Date;
  tripType: string;
  destination: string;
  departure: string;
  checkin: boolean;
  price: number;
}

const Booking: React.FC = () => {
  const navigate = useNavigate();
  // const StoredBookingIdData = localStorage.getItem("bookingsIdData");
  // const bookingsID = StoredBookingIdData ? JSON.parse(StoredBookingIdData) : [];

  const token = localStorage.getItem('token'); // Get the JWT token from local storage
  const [bookings, setBookings] = useRecoilState(userBookingState)
  // let bookings: BookingDetails[] = [];

  const storedUserData = localStorage.getItem("userData");
  const userData = storedUserData ? JSON.parse(storedUserData) : null;

  let refid = userData?.refid;
  // const [fetchedId, setFetchedID] = useState([]);

  const [bookingHandled, setBookingHandled] = useState(false); // Add state variable


  useEffect(() => {
    if (!token) {
      navigate('/login')
    }

    isAuth()
      .then(auth => {
        // Handle successful authentication
        if (!auth) {
          navigate('/login')
        }
        // console.log('Logged in as:', auth);
      })
      .catch(error => {
        // Handle authentication error
        console.error('Authentication error:', error);
      });


    const fetchBookings = async () => {
      try {

        try {
          const response = await axios.get(
            `${process.env.REACT_APP_SERVER}/api/get-booking`,
            {
              headers: {

                'Authorization': `Bearer ${token}`, // Include the JWT token in the request headers
                'Content-Type': 'application/json',
              }
            }
          );


          console.log(response.data.bookings)
          setBookings(response.data.bookings)
        } catch (error) {
          console.error("Error fetching booking:", error);
        }
        //
      } catch (error) {
        console.error("Error fetching bookings:", error);
      }
    };

    const handleBooking = async () => {
      console.log("handle booking ")


      if (!refid) {
        return;

      }
      let endpoint = `${process.env.REACT_APP_SERVER}/api/update-payment`;


      try {
        const response = await axios.post(endpoint, { refid }, {
          headers: {
            'Authorization': `Bearer ${token}`, // Include the JWT token in the request headers
            'Content-Type': 'application/json',
          },
        });

        console.log("handle booking ", response.data)
        if (response.data.success) {

          toast.success("Flight booked successfully");


          // localStorage.removeItem("userData");
          // window.location.href = "/booking";
          navigate('/booking')
        } else {
          const errorMessage = response.data.message;

          if (
            errorMessage.includes("departure") &&
            response.data.availableSeats
          ) {
            toast.error(
              `${errorMessage}. Seats left: ${response.data.availableSeats}`,
            );
          } else if (
            errorMessage.includes("return") &&
            response.data.availableSeatsOutbound &&
            response.data.availableSeatsReturn
          ) {
            toast.error(
              `${errorMessage}. Seats left for outbound: ${response.data.availableSeatsOutbound}, Seats left for return: ${response.data.availableSeatsReturn}`,
            );
          } else {
            toast.error(errorMessage);
          }
        }
      } catch (error) {
        console.error("Error saving form data:", error);
        toast.error("An error occurred while booking your flight");
      } finally {
      }
    }


    const mainfnc = async () => {


      const clientSecret = new URLSearchParams(window.location.search).get(
        "payment_intent_client_secret"
      );

      const currentUrl = window.location.href;

      // Parse the query string parameters
      const urlSearchParams = new URLSearchParams(currentUrl);

      // Get the value of the "redirect_status" parameter
      const redirectStatus = urlSearchParams.get('redirect_status');

      // Log or use the redirect status as needed
      // fetchPaymentStatus()
      console.log(redirectStatus)
      console.log(clientSecret)

      if (userData != null && userData.client_secret === clientSecret && redirectStatus === "succeeded") {
        if (!bookingHandled) {
          await handleBooking();
          setBookingHandled(true); // Set bookingHandled to true after handling booking
        }
        localStorage.removeItem("userData");

        await fetchBookings();
        // localStorage.removeItem("userData");
      } else {

        console.log("false")
        fetchBookings();
        localStorage.removeItem("userData");
      }

    }
    mainfnc()
    fetchBookings();
  }, []);

  return (
    <div>
      {bookings.length === 0 ? (
        <div className="text-center text-gray-600 mt-8">
          <Alert>
            {/* <Terminal className="h-4 w-4" /> */}
            <AlertTitle>No booking </AlertTitle>
            <AlertDescription>
              You currently do not have any bookings.
            </AlertDescription>
          </Alert>
        </div>
      ) : (
        <Carousel>
          {bookings.map((booking: BookingDetails, index: number) => (



            <main className="flex min-h-screen flex-col items-center justify-center p-4">
              <div key={index} className="p-1 rounded-md shadow-md w-full max-w-xl m-4 sm:m-12 flex items-center justify-center">
                <div className="flex flex-col">
                  <div className="bg-white relative drop-shadow-2xl rounded-3xl p-4 sm:p-8 m-4">
                    <div className="flex-none sm:flex">
                      <div className="flex-auto justify-evenly">
                        <div className="flex items-center justify-between">
                          <div className="ml-auto text-red-800 text-lg">
                            {booking.tripType && booking.tripType}
                          </div>
                        </div>
                        <div className="border-dashed border-b-2 my-4 sm:my-6"></div>
                        <div className="flex flex-col m-2 ">
                          {/* Departure Details */}
                          <div className="flex flex-col w-full ">
                            {booking.departdate && (
                              <div className="text-s text-gray-800 my-2">
                                <span className="mr-2">
                                  {new Date(
                                    booking.departdate,
                                  ).toLocaleDateString("en-US", {
                                    weekday: "short",
                                  })}
                                </span>
                                <span className="text-lg font-bold mb-8">
                                  {new Date(
                                    booking.departdate,
                                  ).toLocaleDateString("en-US", {
                                    day: "numeric",
                                    month: "numeric",
                                  })}
                                </span>
                              </div>
                            )}
                            {booking.departure && (
                              <>
                                <div className="text-lg text-red-800 font-bold leading-none">
                                  Departure
                                </div>
                                <div className="text-sm mb-8">{booking.departure}</div>
                              </>
                            )}
                          </div>
                          {/* Arrival Details */}
                          <div className="flex flex-col w-full ">
                            {booking.destination && (
                              <>
                                <div className="text-lg text-red-800 font-bold leading-none">
                                  Arrival
                                </div>
                                <div className="text-sm">{booking.destination}</div>
                              </>
                            )}
                          </div>
                        </div>
                        {/* Flight Details */}
                        <div className="flex items-center my-2 sm:my-6 sm:p-6 text-base">
                          <div className="flex flex-col w-full">
                            <span className=" text-red-800 font-bold leading-none">
                              Flight
                            </span>
                            {booking.tripType && (
                              <div className="font-semibold text-lg">
                                {booking.tripType}
                              </div>
                            )}
                          </div>
                        </div>
                        {/* Passengers Details */}
                        <div className="border-b border-dashed my-4 sm:my-6 pt-4 sm:pt-6">
                          <div className="absolute rounded-full w-6 h-6 bg-red-900 mt-3 -left-3"></div>
                          <div className="absolute rounded-full w-6 h-6 bg-red-900 mt-3 -right-3"></div>
                        </div>
                        <div className="flex items-center justify-center flex-wrap sm:flex-no-wrap px-4 sm:px-6 pt-4 sm:pt-6 text-base">
                          {booking.passengersNo && booking.passengersNo > 1 ? (
                            <div className="flex flex-col w-full sm:w-auto">
                              <span className=" text-red-800 font-bold leading-none">
                                Passengers
                              </span>{" "}
                              <div className="font-semibold sm:text-m">
                                {booking.firstName} {booking.lastName}
                              </div>
                              {booking.passengers.map((passenger) => (
                                <div key={passenger.email}>
                                  <div className="font-semibold sm:text-m">
                                    {passenger.firstName} {passenger.lastName}
                                  </div>
                                </div>
                              ))}
                            </div>
                          ) : (
                            <div className="flex flex-col w-full sm:w-auto">
                              <span className=" text-red-800 font-bold leading-none">
                                Passenger
                              </span>
                              {booking.firstName && booking.lastName && (
                                <div className="font-semibold sm:text-m">
                                  {booking.firstName} {booking.lastName}
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                        {/* Other Details */}
                        <div className="flex items-center px-4 sm:px-6 pt-4 sm:pt-6 text-base">
                          <div className="flex flex-col w-full">
                            <span className=" text-red-800 font-bold leading-none">
                              Number of Passengers
                            </span>
                            {booking.passengersNo && (
                              <div className="font-semibold sm:text-m">
                                {booking.passengersNo}
                              </div>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center px-4 sm:px-6 pt-4 sm:pt-6 text-base">
                          <div className="flex flex-col w-full">
                            <span className=" text-red-800 font-bold leading-none">Email</span>
                            {booking.email && (
                              <div className="font-semibold sm:text-m">
                                {booking.email}
                              </div>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center px-4 sm:px-6 pt-4 sm:pt-6 text-base">
                          <div className="flex flex-col w-full">
                            <span className=" text-red-800 font-bold leading-none">Phone</span>
                            {booking.phone && (
                              <div className="font-semibold sm:text-m">
                                {booking.phone}
                              </div>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center px-4 sm:px-6 pt-4 sm:pt-6 text-base">
                          <div className="flex flex-col w-full">
                            <span className=" text-red-800 font-bold leading-none">
                              Check in Luggage
                            </span>
                            {booking.checkin && (
                              <div className="font-semibold sm:text-m">
                                {booking.checkin}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </main>

          ))}
        </Carousel>
      )}
    </div>
  );

};
export default Booking;


