
import { PageHeader, PageHeaderHeading } from "../components/page-header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Label } from "../components/ui/label";
import { useRecoilState } from "recoil";
import { checkinState } from "../store/form_store";

import { toast } from "react-toastify";
export default function Want() {
  const [checkin, setCheckin] = useRecoilState(checkinState);
  return (
    <>
      <PageHeader>
        <PageHeaderHeading>Booking </PageHeaderHeading>
      </PageHeader>
      <Card>
        <CardHeader>
          <CardTitle>Booking Title</CardTitle>
          <CardDescription>Booking description.</CardDescription>
          <CardContent>
            <div className="mb-5">

              <Label
                htmlFor="checkin"
                className="block mb-2 text-m font-medium "
              >
                Check-in luggage
              </Label>
              <div className="flex items-center">
                <button
                  type="button"
                  onClick={(e) => {
                    if (checkin < 2) {
                      toast.error("We provide one checkin for free ");
                      return;
                    }
                    setCheckin(Number(checkin) - 1);
                  }}
                  className="mr-2 bg-red-500 text-white px-3 py-1 rounded-lg"
                >
                  -
                </button>
                <div className="flex items-center">
                  <img
                    src="https://cdn-icons-png.flaticon.com/128/607/607286.png"
                    className="h-12 mr-2"
                    alt="passenger-icon"
                  />
                  <span className="text-m font-semibold">{checkin}</span>
                </div>
                <button
                  type="button"
                  onClick={(e) => {
                    if (checkin === 5) {
                      toast.error("We provide Atmost 5 checkin ");
                      return;
                    }
                    setCheckin(Number(checkin) + 1);
                  }}
                  className="ml-2 bg-red-500 text-white px-3 py-1 rounded-lg"
                >
                  +
                </button>
              </div>
            </div>
          </CardContent>
        </CardHeader>
      </Card>
    </>
  )
}
