
import React from "react";
import { ElementProps, Elements } from "@stripe/react-stripe-js";
import { loadStripe, StripeElementsOptions } from "@stripe/stripe-js";
import CheckoutForm from "../components/CheckoutForm";
const stripePromise = loadStripe(`${process.env.REACT_APP_STRIPE_PUBLIC_KEY}`);

function Checkout() {
  const storedUserData = localStorage.getItem("userData");
  const userData = storedUserData ? JSON.parse(storedUserData) : null;

  const clientSecret = userData.client_secret;
  const appearance = {
    theme: "flat",
  } as StripeElementsOptions;

  const options = {
    clientSecret,
    appearance,
  } as StripeElementsOptions;

  return (
    <section className='flex min-h-screen flex-col items-center justify-center p-4 sm:p-8 md:p-12 lg:p-16 xl:p-24'> {/* Centering vertically and horizontally */}
      <h1 className="text-2xl font-extrabold tracking-tight text-nowrap  text-center sm:text-4xl mb-8 "> {/* Increase font size and add bottom margin */}
        Secure Payment Gateway

      </h1>
      <div>
        {clientSecret && (
          <Elements options={options} stripe={stripePromise}>
            <CheckoutForm />
          </Elements>
        )}
      </div>
    </section >
  );
}
export default Checkout;
