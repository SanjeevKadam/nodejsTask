import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useRecoilState, useRecoilValue } from "recoil";

import {
  checkinState,
  addressState,
  dobState,
  emailState,
  firstNameState,
  imageUrlState,
  lastNameState,
  phoneState,
} from "../store/form_store";

import {
  departdateState,
  departureFromState,
  destinationState,
  returndateState,
  tripOneState,
  tripTypeState,
} from "../store/home_store";

import { PriceState, SeatsLeftState } from "../store/payment_store";
import { passengerNoState, passengersState } from "../store/pessanger_store";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "../components/ui/card";
import { Passenger } from "../types/pessanger_types";
import { motion } from "framer-motion";
import { fadeIn } from "../variants";

const Confirm = () => {
  const navigate = useNavigate();

  const [isLoading, setIsLoading] = useState(false);
  const [price, setPrice] = useRecoilState(PriceState);
  const [seats, setSeats] = useRecoilState(SeatsLeftState);

  // User Information
  const firstName = useRecoilValue(firstNameState);
  const lastName = useRecoilValue(lastNameState);
  const dob = useRecoilValue(dobState);
  const email = useRecoilValue(emailState);
  const imageURL = useRecoilValue(imageUrlState);
  const phone = useRecoilValue(phoneState);
  const address = useRecoilValue(addressState);
  const checkin = useRecoilValue(checkinState);
  const tripon = useRecoilValue(tripOneState);

  // Flight Information
  const departdate = useRecoilValue(departdateState);
  const returndate = useRecoilValue(returndateState);
  const tripType = useRecoilValue(tripTypeState);
  const destination = useRecoilValue(destinationState);
  const departure = useRecoilValue(departureFromState);

  // Passenger Information
  const passengersNo = useRecoilValue(passengerNoState);
  const passengers = useRecoilValue(passengersState) as Passenger[];


  const token = localStorage.getItem("token");

  useEffect(() => {
    if (!firstName || !token) {
      navigate("/");
      return;
    }

    const fetchData = async () => {
      setIsLoading(true);

      try {
        const response = await axios.get(
          `${process.env.REACT_APP_SERVER}/api/ticket-price`,
          {
            params: {
              firstName,
              lastName,
              dob,
              address,
              email,
              phone,
              imageURL,
              passengers,
              passengersNo,
              departdate,
              returndate,
              tripType,
              destination,
              departure,
              checkin,
              tripon,
            },
            headers: {
              Authorization: `Bearer ${token}`,
              "Content-Type": "application/json",
            },
          }
        );

        if (response.data.success) {
          const price = response.data.price;
          setPrice(price);
          console.log(response.data);
        } else {
          console.log(response.data);
        }
      } catch (error) {
        console.error("Error fetching ticket price:", error);
        toast.error("Error Fetching Ticket Price");
      } finally {
        setIsLoading(false);
      }

      try {
        const response = await axios.get(
          `${process.env.REACT_APP_SERVER}/api/seats-left`,
          {
            params: {
              firstName,
              lastName,
              dob,
              address,
              email,
              phone,
              imageURL,
              passengers,
              passengersNo,
              departdate,
              returndate,
              tripType,
              destination,
              departure,
              checkin,
              tripon,
            },
            headers: {
              Authorization: `Bearer ${token}`,
              "Content-Type": "application/json",
            },
          }
        );

        if (response.data.success) {
          const seats = response.data.seats;
          setSeats(seats);
          if (seats === 0) {
            toast.error("Sorry, we don't have more seats left");
          }
          console.log(response.data);
        } else {
          console.log(response.data);
        }
      } catch (error) {
        console.error("Error fetching Left Seats:", error);
        toast.error("Error Fetching Left Seats");
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, [
    address,
    checkin,
    departdate,
    departure,
    destination,
    dob,
    email,
    firstName,
    imageURL,
    lastName,
    navigate,
    passengers,
    passengersNo,
    phone,
    returndate,
    token,
    tripType,
    tripon,
    setPrice,
    setSeats,
  ]);

  const formattedDate = (date: Date | null) => (date ? new Date(date).toDateString() : "");

  const handleBack = () => {
    navigate("/luggage");
  };

  const handleSubmit = async () => {
    setIsLoading(true);
    let refid;

    try {
      const response = await axios.post(
        `${process.env.REACT_APP_SERVER}/api/bookingFormData/${tripon}`,
        {
          firstName,
          lastName,
          dob,
          address,
          email,
          phone,
          imageURL,
          passengers,
          passengersNo,
          departdate,
          returndate,
          tripType,
          destination,
          departure,
          checkin,
          price,
          tripon,
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        }
      );

      console.log("handle booking ", response.data);
      if (response.data.success) {
        refid = response.data.refid;
      } else {
        const errorMessage = response.data.message;

        if (
          errorMessage.includes("departure") &&
          response.data.availableSeats
        ) {
          toast.error(
            `${errorMessage}. Seats left: ${response.data.availableSeats}`
          );
        } else if (
          errorMessage.includes("return") &&
          response.data.availableSeatsOutbound &&
          response.data.availableSeatsReturn
        ) {
          toast.error(
            `${errorMessage}. Seats left for outbound: ${response.data.availableSeatsOutbound}, Seats left for return: ${response.data.availableSeatsReturn}`
          );
        } else {
          toast.error(errorMessage);
        }
      }
    } catch (error) {
      console.error("Error saving form data:", error);
      toast.error("An error occurred while booking your flight");
    }

    try {
      const response = await axios.get(
        `${process.env.REACT_APP_SERVER}/secret`,
        {
          params: {
            price,
          },
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        }
      );

      const { client_secret, payid } = response.data;
      if (!client_secret) {
        navigate("/");
        return;
      }

      const userData = {
        refid,
        client_secret,
        payid,
      };

      localStorage.setItem("userData", JSON.stringify(userData));
      navigate("/checkout");
    } catch (error) {
      console.error("Error fetching secret:", error);
      toast.error("An error occurred while processing your payment");
    }
  };


  return (

    <motion.div
      variants={fadeIn('down', 0.1)}
      initial='hidden'
      whileInView={'show'}
      viewport={{ once: false, amount: 0 }}

    >
      <div className="flex items-center justify-center m-auto mt-5 mb-5">
        <Card className="w-[350px] lg:w-[650px] md:w-[450px]">
          <CardHeader className="flex items-center">
            <CardTitle className="text-xl font-bold" >Confirm Your Details</CardTitle>
          </CardHeader>
          <CardContent>
            <hr className="my-4 border-t border-gray-300" />

            <div className="text-center diplay-flex align-center mb-6">
              <div>
                <p className="text-xl mx-36 font-bold text-red-800 mb-2">
                  Seats Left: {seats}
                </p>
                <p className="text-m text-gray-600">Secure your seat now!</p>
              </div>
            </div>


            <div className="flex items-center justify-center flex-col mb-7">
              {passengersNo && passengersNo > 1 ? (
                <>
                  <img
                    src={imageURL}
                    alt="User"
                    className="rounded-full border-5 border-red-500 w-20 h-20 mr-4"
                  />
                  <p className="text-gray-801 text-m font-semibold">{`${firstName} ${lastName}`}</p>
                  {passengers.map((passenger, index) => (
                    <React.Fragment key={index}>
                      <img
                        src={passenger.imageURL}
                        alt="User"
                        className="rounded-full border-5 border-red-500 w-20 h-20 mr-4"
                      />
                      <p className="text-gray-801 text-m font-semibold">{`${passenger.firstName} ${passenger.lastName}`}</p>
                    </React.Fragment>
                  ))}
                </>
              ) : (
                <>
                  <img
                    src={imageURL}
                    alt="User"
                    className="rounded-full border-5 border-red-500 w-20 h-20 mr-4"
                  />
                  <p className="text-gray-801 text-m font-semibold">{`${firstName} ${lastName}`}</p>
                </>
              )}
            </div>
            <hr className="my-4 border-t border-gray-300" />

            <div className="mb-6 text-center">
              <div className="text-gray-800 text-m">
                <p className="font-semibold">Departure Date: {formattedDate(departdate)}</p>
                {returndate && (
                  <p className="font-semibold">Return Date: {formattedDate(returndate)}</p>
                )}
                <p className="font-semibold">Trip Type: {tripType}</p>
                <p className="font-semibold">Trip On: {tripon}</p>
              </div>
              <div className="text-gray-800 text-m mt-2">
                <p className="font-semibold">Destination: {destination}</p>
                <p className="font-semibold">Departure: {departure}</p>
              </div>
            </div>

            <hr className="my-4 border-t border-gray-300" />

            <div className="mb-6 text-center">
              <div className="text-gray-800 text-m">
                <p className="font-semibold">Number of Passengers: {passengersNo}</p>
                <p className="font-semibold">Total luggage: {checkin}</p>
              </div>
              <div className="text-red-800 text-xl mt-2">
                <p className="font-semibold">Total Price: ${price}</p>
              </div>
            </div>

            <hr className="my-4 border-t border-gray-300" />

            <div className="flex justify-center mt-6">
              <button
                type="button"
                onClick={handleBack}
                className="text-gray-700 bg-gray-300 hover:bg-gray-400 focus:ring-4 focus:outline-none focus:ring-gray-500 font-medium rounded-lg text-m px-6 py-3 mr-4"
              >
                Back
              </button>
              <button
                type="submit"
                disabled={seats === 0 || isLoading}
                onClick={handleSubmit}
                className="text-white bg-red-600 hover:bg-red-700 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-m px-6 py-3"
              >
                {isLoading ? "Saving..." : "Book Now"}
              </button>
            </div>
          </CardContent>
          <CardFooter className="flex justify-end">
            {/* <Button>Book Now</Button> */}
          </CardFooter>
        </Card>
      </div >

    </motion.div>
  );
};
export default Confirm;
