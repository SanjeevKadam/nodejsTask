import { useEffect, useState } from "react";
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { toast } from "react-toastify";

const Confirmation = () => {
  const navigate = useNavigate()
  const location = useLocation();
  const [message, setMessage] = useState('');
  const [verified, setVerified] = useState(false);

  useEffect(() => {
    const confirmEmail = async () => {
      const parts = location.pathname.split('/');
      const email = parts[2];
      const token = parts[3];

      try {
        const response = await fetch(`${process.env.REACT_APP_SERVER}/confirmation/${email}/${token}`);
        const data = await response.json();

        if (!response.ok) {
          throw new Error(data.msg);
        }

        setMessage(data.msg);
        // toast.success("Email verified")
        setVerified(true); // Set verified state to true

        // const handleLoginIn = async () => {
        localStorage.removeItem('token'); // Store token locally
        try {
          const response = await fetch(`${process.env.REACT_APP_SERVER}/user/login`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ email }),
          });

          if (!response.ok) {
            const data = await response.json();
            throw new Error(data.msg);
          }

          const data = await response.json();
          localStorage.setItem('token', data.token); // Store token locally
          toast.success('Successfully Login!')
          // window.location.href = "/book";
          navigate('/book');
        } catch (error: any) {
          // setError(error.message);
          toast.error(error.message)
        }
        // };
      } catch (error: any) {
        setMessage(error.message);
      }
    };

    confirmEmail();
  }, []);

  return (
    <section className='flex min-h-screen flex-col items-center justify-center sm:text-nowrap p-4 sm:p-8 md:p-12 lg:p-16 xl:p-24'> {/* Centering vertically and horizontally */}
      <h1 className="text-4xl font-extrabold tracking-tight lg:text-3xl mb-8"> {/* Increase font size and add bottom margin */}
        Confirmation of Email
      </h1>
      {verified ? ( // Conditionally render message if email is verified
        <p>
          Email verified successfully! You can now proceed to{" "}
          <button onClick={() => { navigate("/login") }}>Login</button>
        </p>
      ) : (
        <p>{message}</p> // Display other messages
      )}
    </section>
  );
};

export default Confirmation;
