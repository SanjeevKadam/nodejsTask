import svgpath from "../consants"
import ReactGoogleAutocomplete from "react-google-autocomplete";

import { Autocomplete } from "@react-google-maps/api"
import { Calendar } from "../components/ui/calendar"
import { cn, isOldEnough } from "../lib/utils"
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "../components/ui/card"
import { PageHeader, PageHeaderHeading } from "../components/page-header";
import axios from "axios";
import React, { useEffect, useState } from "react";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { useNavigate } from "react-router-dom";
import { useRecoilState, useRecoilValue } from "recoil";
import { format } from "date-fns"
import { CalendarIcon } from "lucide-react"
import {
  addressState,
  dobState,
  checkinState,
  emailState,
  firstNameState,
  imageUrlState,
  lastNameState,
  phoneState,
} from "../store/form_store";

import { departdateState } from "../store/home_store";
import { passengerNoState, passengersState } from "../store/pessanger_store";

import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "../components/ui/form"
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "../components/ui/popover"
import { Input } from "../components/ui/input"
import PhoneInput from "react-phone-number-input";
import "react-phone-number-input/style.css";

import { Label } from "../components/ui/label"
import { Button } from "../components/ui/button";
import { toast } from "react-toastify";
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from 'zod'


import { isValidPhoneNumber } from "react-phone-number-input";
import { motion } from "framer-motion";
import { fadeIn } from "../variants";
const formSchema = z.object({
  firstName: z.string().min(2, {
    message: "firstName must be at least 2 characters.",
  }),
  lastName: z.string().min(2, {
    message: "firstName must be at least 2 characters.",
  }), emailAddress: z.string().email(),

  phone: z.string().refine(isValidPhoneNumber, 'Invalid Number!'),
  // dob: z.coerce.number().gt(17, {
  //   message: "You should be a adult to travel .",
  // }),
  // address: z.string().min(10, { message: "address should be minimum 10 character" }),

})

export default function PessangerForm() {

  const navigate = useNavigate();

  const startdate = useRecoilValue(departdateState);

  useEffect(() => {
    localStorage.removeItem("userData");
    if (!startdate) {
      navigate("/");
    }
  }, [navigate, startdate]);

  const [firstName, setFirstName] = useRecoilState(firstNameState);
  const [lastName, setLastName] = useRecoilState(lastNameState);
  const [dob, setDob] = useRecoilState<Date>(dobState);

  const [address, setAddress] = useRecoilState(addressState);
  const [phone, setPhone] = useRecoilState(phoneState);
  const [imageURL, setImageUrl] = useRecoilState(imageUrlState);

  const [checkin, setCheckin] = useRecoilState(checkinState);
  const [email, setEmail] = useRecoilState(emailState);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      firstName: firstName,
      lastName: lastName,
      emailAddress: email,
      phone: phone,
      // dob: dob,
      // address: address
    },
  })

  const [selectedFile, setSelectedFile] = useState(null);

  const [isLoading, setIsLoading] = useState(false);
  // const [passenger,Setpassenger] = useState(passengerState);

  const passengersNo = useRecoilValue(passengerNoState);
  const passengers = useRecoilValue(passengersState);

  const [isFileUploaded, setIsFileUploaded] = useState(false);

  const [randomId, setRandomId] = useState("");

  const handleBack = () => {
    navigate("/");
  };

  // const handleDateChange = (selectedDate: Date) => {
  //   const parsedDate = new Date(selectedDate);
  //   setDob(parsedDate);
  // };

  const handleFileChange = (e: any) => {
    setSelectedFile(e.target.files[0]);
    setIsFileUploaded(false);
  };

  const notify = () => {
    toast.success("Photo Uploaded!");
  };

  const handleUpload = async () => {
    if (!selectedFile) {
      toast.error("Please select a file first");
      return;
    }

    setIsLoading(true);

    const characters =
      "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    let randomId = "";

    for (let i = 0; i < 8; i++) {
      const randomIndex = Math.floor(Math.random() * characters.length);
      randomId += characters.charAt(randomIndex);
    }

    const formData = new FormData();
    setRandomId(randomId);
    formData.append("fileId", randomId);
    formData.append("file", selectedFile);

    console.log(process.env.REACT_APP_SERVER)
    try {
      const response = await axios.post(
        `${process.env.REACT_APP_APPWRITE_URL}`,
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
            "X-Appwrite-Response-Format": "1.4.0",
            "X-Appwrite-Project": `${process.env.REACT_APP_APPWRITE_PROJECT}`,
            "X-Appwrite-Key": `${process.env.REACT_APP_APPWRITE_KEY}`,
          },
        },
      );

      setIsFileUploaded(true);
      setImageUrl(
        `${process.env.REACT_APP_APPWRITE_URL}/${randomId}/view?project=${process.env.REACT_APP_APPWRITE_PROJECT}&mode=admin`,
      );
      notify();
    } catch (error) {
      console.log("Axios upload error ", error);
      toast.error("Error uploading file");
    } finally {
      setIsLoading(false);
    }
  };

  // const handleSubmit = async (e: any) => {
  //   e.preventDefault();
  //
  //   if (!address) {
  //     toast.error("Please Type and select address")
  //     return;
  //   }
  //
  //   if (
  //     !firstName ||
  //     !lastName ||
  //     !dob ||
  //     !address ||
  //     !email ||
  //     !imageURL ||
  //     !phone
  //   ) {
  //     toast.error("Please fill in all the fields");
  //     return;
  //   }
  //
  //   setIsLoading(true);
  //   toast.success("Form Filled Successfully");
  //   navigate("/confirm");
  // };
  //
  const handleSubmit = (values: z.infer<typeof formSchema>) => {
    // if (!imageURL) {
    //   toast.error('Please Upload an Image')
    //   return;
    //
    // }
    console.log("tset")
    if (!isOldEnough(dob)) {
      toast.error("You are not old enough to travel ")
      return;
    }

    if (!address) {
      toast.error("Please Input a proper address ")
      return;
    }

    setFirstName(values.firstName)
    setLastName(values.lastName)
    // setAddress(values.address)
    // setDob(values.dob)
    // setDob(dob)
    // setAddress(address)
    setPhone(values.phone)
    setEmail(values.emailAddress)
    console.log("tset1")
    navigate('/want')

  };

  const handleDateChange = (selectedDate: Date) => {
    // const parsedDate = new Date(selectedDate);
    setDob(selectedDate);
  };


  return (
    <motion.div
      variants={fadeIn('down', 0.1)}
      initial='hidden'
      whileInView={'show'}
      viewport={{ once: false, amount: 0 }}

    >
      <main className="flex min-h-screen flex-col items-center justify-center p-24">
        <div className="flex items-center justify-center">
          <Card className="w-[350px] lg:w-[650px] md:w-[450px]">
            <CardHeader>
              <CardTitle>Enter Passengers Details </CardTitle>
              {/* <CardDescription>Book </CardDescription> */}
            </CardHeader>
            <CardContent>
              <hr className="my-4 border-t border-gray-300" />
              <Form {...form}>
                <form
                  onSubmit={form.handleSubmit(handleSubmit)}
                  className="max-w-md w-full mx-auto flex flex-col gap-4 justify-center"
                >
                  <FormField
                    control={form.control}
                    name="firstName"

                    render={({ field }) => {
                      return (
                        <FormItem>
                          <FormLabel>First Name</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="First Name"
                              type="string"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      );
                    }}
                  />
                  <FormField
                    control={form.control}
                    name="lastName"

                    render={({ field }) => {
                      return (
                        <FormItem>
                          <FormLabel>Last Name</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="Last Name"
                              type="string"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      );
                    }}
                  />
                  <FormField
                    control={form.control}
                    name="emailAddress"
                    render={({ field }) => {
                      return (
                        <FormItem>
                          <FormLabel>Email address</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="Email address"
                              type="email"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      );
                    }}
                  />
                  <FormField
                    control={form.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem className="flex flex-col items-start">
                        <FormLabel className="text-left">Phone Number</FormLabel>
                        <FormControl className="w-full">
                          <PhoneInput {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="flex mb-5 space-x-4">
                    <div className="w-1/2">
                      <Label
                        htmlFor="dob"
                        className="block mb-2 text-m font-medium "
                      >
                        Date of Birth
                      </Label>
                      <DatePicker
                        id="dob"
                        selected={dob}
                        placeholderText="mm/dd/yyyy"
                        filterDate={(date: Date) => date < new Date() && isOldEnough(date)}
                        onChange={handleDateChange}
                        onSelect={(date: Date) => setDob(date)}
                        className="peer border-b border-red-gray-200 w-full lg:w-3/4 pt-1.5 pb-1.5 font-sans text-m font-normal text-red-gray-700 outline outline-0 transition-all placeholder-shown:border-red-gray-200 focus:border-gray-500 focus:outline-0 disabled:border-0 disabled:bg-red-gray-50 placeholder:opacity-100"
                        required
                      />
                    </div>
                  </div>
                  <div className="w-1/2">
                    <Label
                      htmlFor="address"
                      className="block mb-2 text-m font-medium "
                    >
                      Address
                    </Label>
                    <ReactGoogleAutocomplete
                      apiKey={`${process.env.REACT_APP_GOOGLE_ADDRESS_API_KEY}`}
                      defaultValue={address}
                      onPlaceSelected={(place) => {
                        console.log(place)
                        if (place && place.formatted_address)
                          setAddress(place.formatted_address)
                      }}
                      options={{
                        componentRestrictions: { country: "us" },
                        // types: ['address'],
                        types: ['street_address', "postal_code"],
                      }}
                      className=" w-full lg:w-96 peer border-b border-red-gray-200   pt-1.5 pb-1.5 font-sans text-m font-normal text-red-gray-700 outline outline-0 transition-all placeholder-shown:border-red-gray-200 focus:border-gray-500 focus:outline-0 disabled:border-0 disabled:bg-red-gray-50 placeholder:opacity-100"


                    />
                  </div>

                  <div className="mb-5">
                    <Label
                      htmlFor="photo"
                      className="block mb-2 text-m font-medium "
                    >
                      Photo
                    </Label>
                    <div className="flex items-center justify-center space-x-4">
                      <div className="w-16 h-16 rounded-full overflow-hidden bg-gray-200 flex-shrink-0">
                        {isLoading ? (
                          <div
                            role="status"
                            className="flex items-center justify-center ml-1 mt-2"
                          >
                            <svg
                              aria-hidden="true"
                              className="w-8 h-8 text-gray-200 animate-spin fill-red-600"
                              viewBox="0 10 100 101"
                              fill="none"
                              xmlns="http://www.w3.org/2000/svg"
                            >
                              {/* come back*/}

                              {svgpath}
                            </svg>
                            <span className="sr-only">Loading...</span>
                          </div>
                        ) : isFileUploaded || imageURL ? (
                          <img
                            src={imageURL}
                            alt="Uploaded"
                            className="w-full h-full object-cover rounded-full"
                          />
                        ) : null}
                      </div>
                      <Input
                        type="file"
                        id="photo"
                        onChange={handleFileChange}
                        className="grid w-full max-w-sm items-center gap-1.5"
                        accept="image/*"
                      />
                      <button
                        type="button"
                        onClick={handleUpload}
                        className="p-2.5 bg-red-600 hover:bg-red-700 text-white text-m rounded-lg focus:ring-red-500 focus:border-red-500"
                      >
                        Upload
                      </button>
                    </div>
                  </div>
                  <div className="flex justify-between mt-6">
                    <button
                      type="button"
                      onClick={() => { navigate('/book') }}
                      className="text-gray-700 bg-gray-300 hover:bg-gray-400 focus:ring-4 focus:outline-none focus:ring-gray-500 font-medium rounded-lg text-m px-5 py-2.5 text-center"
                    >
                      Back
                    </button>
                    <button
                      onClick={form.handleSubmit(handleSubmit)} // Replace type="submit" with onClick
                      className="text-white bg-red-600 hover:bg-red-700 focus:ring-4 focus:outline-none focus:ring-red-300 font-medium rounded-lg text-m px-5 py-2.5 text-center"
                    >
                      Next
                    </button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
        </div>
      </main >
    </motion.div>
  );
}
