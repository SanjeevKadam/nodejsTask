import { toast } from "react-toastify";
import { PageHeader, PageHeaderHeading } from "../components/page-header";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "../components/ui/card";
import { Label } from "../components/ui/label";
import { useRecoilState, useRecoilValue } from "recoil";
import { passengersState } from "../store/pessanger_store";
import { passengerNoState } from "../store/pessanger_store";
import { Button } from "../components/ui/button";
import { useNavigate } from "react-router-dom";
import { checkinState, firstNameState } from "../store/form_store";
import { useEffect } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { fadeIn } from "../variants";
import { motion } from "framer-motion";

export default function Luggage() {
  const navigate = useNavigate();

  const [checkin, setCheckin] = useRecoilState(checkinState);
  const passengersNo = useRecoilValue(passengerNoState);
  let Can_add = passengersNo < 5 ? true : false;

  const firstName = useRecoilValue(firstNameState)

  useEffect(() => {

    if (!firstName) {
      navigate('/form')
    }
  }, [])
  return (
    <section className='flex min-h-screen flex-col items-center justify-center p-4 sm:p-8 md:p-12 lg:p-16 xl:p-24'> {/* Centering vertically and horizontally */}
      <h1 className="text-2xl sm:text-nowrap font-extrabold tracking-tight lg:text-3xl mb-8"> {/* Increase font size and add bottom margin */}

        Do you want to carry extra luggage?
      </h1>
      <motion.div
        variants={fadeIn('up', 0.1)}
        initial='hidden'
        whileInView={'show'}
        viewport={{ once: false, amount: 0 }}

      >
        <div className="flex items-center justify-center m-auto mt-5">
          <div>
            <PageHeader>
              {/* <PageHeaderHeading>Booking </PageHeaderHeading> */}
            </PageHeader>
            <Card className="w-[350px] lg:w-[650px] md:w-[450px]" >
              <CardHeader className="justify-center flex items-center">
                {/* <CardTitle>Add more Luggage </CardTitle> */}
                <CardDescription>Each luggage can weigh up to 50 pounds and costs $30 each.</CardDescription>
              </CardHeader>
              <CardContent>

                <div className="flex items-center flex-col justify-center m-auto mt-5">
                  <Label
                    htmlFor="checkin"
                    className="block mb-2 text-m font-medium "
                  >
                    Check-in luggage
                  </Label>
                  <div className="flex items-center">
                    <button
                      type="button"
                      onClick={(e) => {
                        if (checkin < 2) {
                          toast.error("We provide one checkin for free ");
                          return;
                        }
                        setCheckin(Number(checkin) - 1);
                      }}
                      className="mr-2 bg-red-500 text-white px-3 py-1 rounded-lg"
                    >
                      -
                    </button>
                    <div className="flex items-center">
                      <img
                        src="https://cdn-icons-png.flaticon.com/128/607/607286.png"
                        className="h-12 mr-2"
                        alt="passenger-icon"
                      />
                      <span className="text-m font-semibold">{checkin}</span>
                    </div>
                    <button
                      type="button"
                      onClick={(e) => {
                        if (checkin === 5) {
                          toast.error("We provide Atmost 5 checkin ");
                          return;
                        }
                        setCheckin(Number(checkin) + 1);
                      }}
                      className="ml-2 bg-red-500 text-white px-3 py-1 rounded-lg"
                    >
                      +
                    </button>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">

                <Button onClick={() => { navigate("/want") }}>

                  <ChevronLeft className="h-4 w-4" />
                  Back</Button>
                <Button onClick={() => { navigate("/confirm") }}>

                  Next
                  <ChevronRight className="h-4 w-4" />
                </Button>

              </CardFooter>
            </Card>
          </div>
        </div>
      </motion.div>
    </section>
  )
}
