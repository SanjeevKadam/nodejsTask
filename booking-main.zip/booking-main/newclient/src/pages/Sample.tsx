import { PageHeader, PageHeaderHeading } from "../components/page-header";
import { Card, CardDescription, CardHeader, CardTitle } from "../components/ui/card";

export default function Sample() {
  return (
    <>
      <PageHeader>
        <PageHeaderHeading>Booking </PageHeaderHeading>
      </PageHeader>
      <Card>
        <CardHeader>
          <CardTitle>Booking Title</CardTitle>
          <CardDescription>Booking description.</CardDescription>
        </CardHeader>
      </Card>
    </>
  )
}
