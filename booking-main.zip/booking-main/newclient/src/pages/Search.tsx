
import SearchBox from '../components/SearchBox';
const Search = () => {
  return (



    <section className='flex min-h-screen flex-col items-center justify-center p-4 sm:p-8 md:p-12 lg:p-16 xl:p-24'> {/* Centering vertically and horizontally */}
      <h1 className="text-2xl font-extrabold tracking-tight text-nowrap  text-center sm:text-4xl mb-8 "> {/* Increase font size and add bottom margin */}
        Welcome to Umoja Airways Booking Portal
      </h1>
      <div className=''>
        <SearchBox /> {/* Ensure SearchBox component is imported and apply flex-grow */}
      </div>
    </section>




  );
};

export default Search;
