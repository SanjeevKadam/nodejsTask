import { useState } from 'react';
import { Button } from "../components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { useNavigate } from "react-router-dom";
import { motion } from 'framer-motion';
import { fadeIn } from '../variants';
import { toast } from 'react-toastify';

export default function Verify() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [otp, setOtp] = useState('');
  const [otpsent, setOtpSent] = useState(false);

  const handleRegister = async () => {
    setMessage("");
    setError("");
    setLoading(true);

    try {
      // Validate email format
      if (!/\S+@\S+\.\S+/.test(email)) {
        throw new Error('Please enter a valid email address.');
      }

      const response = await fetch(`${process.env.REACT_APP_SERVER}/sendOTP`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.msg);
      }

      setMessage(data.msg);
      setOtpSent(true);
      setError('');
    } catch (error: any) {
      setError(error.message);
      setMessage('');
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOTP = async () => {
    setMessage("");
    setError("");
    setLoading(true);

    try {
      // Validate OTP format (6 digits)
      if (!/\S+@\S+\.\S+/.test(email)) {
        throw new Error('Please enter a 6-digit OTP.');
      }

      const response = await fetch(`${process.env.REACT_APP_SERVER}/verifyOTP`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, otp }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Failed to verify OTP');
      }

      localStorage.setItem('token', data.token);
      toast.success('Successfully Logged in!');
      navigate("/");

    } catch (error) {
      console.error(error);
      setError("Failed to verify OTP. Please try again.");
      setMessage('');
    } finally {
      setLoading(false);
    }
  };
  return (
    <motion.div
      variants={fadeIn('down', 0.1)}
      initial='hidden'
      whileInView={'show'}
      viewport={{ once: false, amount: 0 }}
    >
      <div className="flex justify-center items-center min-h-screen ">
        <div className="w-full max-w-md">
          <Card>
            <CardHeader className="space-y-1">
              <CardTitle className="text-2xl text-center">Verification</CardTitle>
              <CardDescription className="text-center text-semibold">
                Enter your email address to begin verification
              </CardDescription>
            </CardHeader>
            <CardContent className="grid gap-3">
              <div className="grid gap-1">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder=""
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>
              {loading && <p className="text-gray-600">Please wait...</p>}
              {error && <p className="text-red-500">{error}</p>}
              {message && <p className="text-green-500">{message}</p>}
              {/* Render OTP input field only if an email has been provided */}
              {email && otpsent && (
                <div className="grid gap-1">
                  <Label htmlFor="otp">OTP</Label>
                  <Input
                    id="otp"
                    type="text"
                    placeholder=""
                    value={otp}
                    onChange={(e) => setOtp(e.target.value)}
                  />
                </div>
              )}
            </CardContent>
            <CardFooter className="flex flex-col">
              {/* Render different buttons based on whether OTP has been entered */}
              {otp ? (
                <Button className="w-full" onClick={handleVerifyOTP} disabled={loading}>
                  {loading ? 'Verifying...' : 'Verify'}
                </Button>
              ) : (
                <Button className="w-full" onClick={handleRegister} disabled={loading}>
                  {loading ? 'Loading...' : 'Next'}
                </Button>
              )}
            </CardFooter>
          </Card>
        </div>
      </div>
    </motion.div>
  );
}
