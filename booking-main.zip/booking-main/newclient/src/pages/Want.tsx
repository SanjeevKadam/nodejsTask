
import { PageHeader, PageHeaderHeading } from "../components/page-header";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "../components/ui/card";
import { Label } from "../components/ui/label";
import { useRecoilState, useRecoilValue } from "recoil";
import { passengersState } from "../store/pessanger_store";
import { passengerNoState } from "../store/pessanger_store";
import { Button } from "../components/ui/button";
import { useNavigate } from "react-router-dom";
import { firstNameState } from "../store/form_store";
import { useEffect } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { fadeIn } from "../variants";
import { motion } from "framer-motion";

export default function Want() {
  const navigate = useNavigate();

  const passengersNo = useRecoilValue(passengerNoState);
  let Can_add = passengersNo < 5 ? true : false;

  const firstName = useRecoilValue(firstNameState)

  useEffect(() => {

    if (!firstName) {
      navigate('/form')
    }
  }, [])

  const HandleAdd = () => {
    // if (!address) {
    //   toast.error("Please Type and select address")
    //   return;
    // }
    // if (
    //   !firstName ||
    //   !lastName ||
    //   // !dob ||
    //   !address ||
    //   !email ||
    //   !imageURL ||
    //   !phone
    // ) {
    //   toast.error("Please fill in all the fields");
    //   return;
    // }
    navigate("/add");
  };

  return (
    <section className='flex min-h-screen flex-col items-center justify-center p-4 sm:p-8 md:p-12 lg:p-16 xl:p-24'> {/* Centering vertically and horizontally */}
      <h1 className="text-2xl  sm:text-nowrap font-extrabold tracking-tight lg:text-3xl mb-8"> {/* Increase font size and add bottom margin */}

        Do you want to add more Passengers with you?
      </h1>

      <motion.div
        variants={fadeIn('up', 0.1)}
        initial='hidden'
        whileInView={'show'}
        viewport={{ once: false, amount: 0 }}

      >
        <div className="flex items-center justify-center m-auto mt-5">
          <div>
            <PageHeader>
              {/* <PageHeaderHeading>Booking </PageHeaderHeading> */}
            </PageHeader>
            <Card className="w-[350px] lg:w-[650px] md:w-[450px]" >
              <CardHeader>
                <CardTitle>Add more passengers </CardTitle>
                {/* <CardDescription>Do you want to add more passengers.</CardDescription> */}
                <CardContent>
                  <div className="flex items-center flex-col justify-center m-auto mt-5">
                    {/* <Label */}
                    {/*   htmlFor="add" */}
                    {/*   className="block mb-2 text-m font-medium " */}
                    {/* > */}
                    {/*   Passengers */}
                    {/* </Label> */}
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center">
                        <img
                          src="https://cdn-icons-png.flaticon.com/128/1077/1077063.png"
                          className="h-12 mr-2"
                          alt="passenger-icon"
                        />
                        <span className="text-m font-semibold">{passengersNo}</span>
                      </div>
                      <button
                        type="button"
                        onClick={HandleAdd}
                        className={`px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-m rounded-md focus:ring-red-500 focus:border-red-500 ${!Can_add && "opacity-50 cursor-not-allowed"
                          }`}
                        disabled={!Can_add}
                      >

                        Add Passenger
                      </button>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="flex  justify-between">

                  <Button onClick={() => { navigate("/form") }}>

                    <ChevronLeft className="h-4 w-4" />
                    Back</Button>
                  <Button onClick={() => { navigate("/luggage") }}>

                    Next
                    <ChevronRight className="h-4 w-4" />
                  </Button>

                </CardFooter>
              </CardHeader>
            </Card>
          </div>
        </div>
      </motion.div>
    </section>
  )
}
