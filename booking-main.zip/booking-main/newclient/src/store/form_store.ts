
import { atom } from "recoil";
import { date } from "zod";

const firstNameState = atom({
  key: "firstNameState",
  default: "",
});

const lastNameState = atom({
  key: "lastNameState",
  default: "",
});

const dobState = atom<Date>({
  key: "dobState",
  default: new Date(),
});

const addressState = atom({
  key: "addressState",
  default: "",
});
const emailState = atom({
  key: "emailState",
  default: "",
});

const phoneState = atom({
  key: "phoneState",
  default: "",
});

const imageUrlState = atom({
  key: "imageUrlState",
  default: "",
});

const checkinState = atom({
  key: "checkinState",
  default: 1,
});

export {
  firstNameState,
  lastNameState,
  dobState,
  addressState,
  emailState,
  imageUrlState,
  phoneState,
  checkinState,
};
