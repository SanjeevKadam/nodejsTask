
import { atom } from "recoil";

const departdateState = atom<null | Date>({
  key: "departdateState",
  // default: new Date(2024, 0, 1),
  default: null,
});

const returndateState = atom<null | Date>({
  key: "returndateState",
  default: null,
});

const tripTypeState = atom({
  key: "tripTypeState",
  default: "one-way",
});

const destinationState = atom({
  key: "destinationState",
  default: "",
});

const departureFromState = atom({
  key: "departureFromState",
  default: "",
});

const tripOneState = atom({
  key: "tripOneState",
  // default: "monday",
  default: "tuesday",
});

export {
  departdateState,
  returndateState,
  tripTypeState,
  destinationState,
  departureFromState,
  tripOneState,
};
