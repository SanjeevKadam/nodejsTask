
import { atom } from "recoil";

const PriceState = atom({
  key: "PriceState",
  default: 0,
});

const SeatsLeftState = atom({
  key: "seats_left",
  default: 0,
});

export { PriceState, SeatsLeftState };
