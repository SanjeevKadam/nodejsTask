
import { atom } from "recoil";
import { Passenger } from "../types/pessanger_types";
const passengerNoState = atom({
  key: "passengerNoState",
  default: 1,
});

const passengersState = atom<Passenger[]>({
  key: "passengersState",
  default: [],
});

export { passengerNoState, passengersState };
