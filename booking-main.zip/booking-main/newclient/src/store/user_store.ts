import { BookingDetails } from "../types/pessanger_types";
import { atom } from "recoil";

const userEmailState = atom({
  key: "userEmailState",
  default: "",
});

const userBookingState = atom<BookingDetails[]>({
  key: "userBookingState",
  default: [],
});


export {
  userEmailState, userBookingState
}
