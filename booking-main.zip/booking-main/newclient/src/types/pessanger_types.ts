
export type Passenger = {
  firstName: string;
  lastName: string;
  dob: Date;
  address: string;
  email: string;
  imageURL: string;
  phone: string;
};
// types.ts

export interface BookingDetails {
  firstName: string;
  lastName: string;
  dob: Date;
  address: string;
  email: string;
  phone: string;
  imageURL: string;
  passengers: Passenger[]; // Assuming an array of passenger names, adjust accordingly
  passengersNo: number;
  departdate: Date;
  returndate: Date;
  tripType: string; // Update with specific types as needed
  destination: string;
  departure: string;
  checkin: boolean;
  price: number;
}
