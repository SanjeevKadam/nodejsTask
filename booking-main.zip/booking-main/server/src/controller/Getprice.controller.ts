import { defaults } from "joi";
import express, { NextFunction, Request, Response } from "express";
import { getPriority } from "os";

interface CustomRequest extends Request {
  query: {
    departure: string;
    destination: string;
    departdate: string;
    tripType: string;
    passengersNo: string | undefined;
    checkin: string | undefined;
    tripon: string;
  };
}
const getPrice = async (req: CustomRequest, res: Response) => {
  console.log("price api");

  try {
    const { destination, departdate, tripType, passengersNo, checkin, tripon, departure } =
      req.query;

    const parsedPassengersNo = Number(passengersNo);
    const parsedCheckin = Number(checkin);

    let price = 0;

    if (tripType === "one-way") {
      if (tripon === "monday") {
        price = 585 * parsedPassengersNo;
      } else if (tripon === "tuesday") {
        // if (destination === "GUY") {
        //   price = 680 * parsedPassengersNo;
        // } else {
        //
        //   price = 300 * parsedPassengersNo;
        // }

        if (destination === "HAV") {
          price = 300 * parsedPassengersNo;
        } else if (destination === "POS") {

          price = 680 * parsedPassengersNo;
        } else if (destination === "GEO" && departure === "HAV") {
          price = 720 * parsedPassengersNo;
        } else if (destination === "GEO" && departure === "POS") {
          price = 300 * parsedPassengersNo;
        }
      } else if (tripon === "wednesday") {
        // if (destination === "POS" && departure === "MIA") {
        //   price = 680 * parsedPassengersNo;
        // } else if (destination === "MIA" && departure === "POS") {
        //   price = 680 * parsedPassengersNo;
        // } else if (destination === "GUY" && departure === "MIA") {
        //   price = 300 * parsedPassengersNo;
        // } else if (destination === "MIA" && departure === "GUY") {
        //   price = 300 * parsedPassengersNo;
        // }
        if (destination === "POS") {

          price = 300 * parsedPassengersNo;
        } else if (destination === "MBJ") {

          price = 300 * parsedPassengersNo;
        } else if (destination === "HAV" && departure === "GEO") {
          price = 720 * parsedPassengersNo;

        } else if (destination === "HAV" && departure === "POS") {
          price = 680 * parsedPassengersNo;

        }
      } else if (tripon === "thursday") {
        if (destination === "POS") {
          price = 680 * parsedPassengersNo;
        } else {

          price = 300 * parsedPassengersNo;
        }
      }
    } else {
      // let flight = await MondayFlightData.findOne({ flightDate: departdate });
      //
      // if (flight !== null && flight !== undefined) {
      //   let availableSeats =
      //     destination === "POS"
      //       ? flight?.Flight1?.availableSeats
      //       : flight?.Flight2?.availableSeats;
      //
      //   const totalSeats = 183;
      //
      //   const bookedSeats = totalSeats - (availableSeats ?? 0);
      //
      //   if (bookedSeats >= 20) {
      //     price = 680 * parsedPassengersNo;
      //   } else {
      //     const discountLeft = 20 - bookedSeats;
      //
      //     if (discountLeft >= parsedPassengersNo) {
      //       price = 680 * parsedPassengersNo;
      //     } else {
      //       price = parsedPassengersNo * 860;
      //       price -= discountLeft * 180;
      //     }
      //   }
      // } else {
      //   // Handle the case when flight is null or undefined
      //   price = 680 * parsedPassengersNo; // or set a default value as needed
      // }
    }

    // setting checkin price
    price = price + parsedCheckin * 30 - parsedPassengersNo * 30;

    return res.status(200).json({
      success: true,
      price: price,
    });
  } catch (error: any) {
    console.error("Error calculating ticket price:", error);
    return res.status(500).json({
      success: false,
      message: "Error calculating ticket price",
      error: error.message,
    });
  }
}
export default getPrice;

