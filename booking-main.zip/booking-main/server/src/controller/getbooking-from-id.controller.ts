import { Request, Response } from "express";
import { Document } from "mongoose";
import BookingData from "../model/booking.model";

const GetBookingFromId = async (req: Request, res: Response) => {
  console.log("Get booking ");

  try {
    const { refid } = req.query;

    if (!refid) {
      return res.status(400).json({
        success: false,
        message: "Booking ID is missing",
      });
    }

    console.log(refid);
    const booking: Document | null = await BookingData.findById(refid);

    if (!booking) {
      return res.status(404).json({
        success: false,
        message: "Booking not found",
      });
    }

    // Convert the booking document to a plain JavaScript object
    const bookingObject = booking.toObject();

    console.log(bookingObject);
    return res.status(200).json({
      success: true,
      booking: bookingObject,
    });
  } catch (error: any) {
    console.error("Error retrieving booking:", error);
    return res.status(500).json({
      success: false,
      message: "Error retrieving booking",
      error: error.message,
    });
  }
};

export default GetBookingFromId;
