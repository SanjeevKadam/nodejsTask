import { Request, Response } from "express";
import { Document } from "mongoose";
import BookingData from "../model/booking.model";

const GetBooking = async (req: any, res: Response) => {
  console.log("Get booking ");

  try {
    const userEmail = req.data.email;

    if (!userEmail) {
      return res.status(400).json({
        success: false,
        message: "User not authorized ",
      });
    }

    const bookings: Document[] = await BookingData.find({ userEmail, isPaid: true });

    if (bookings.length === 0) {
      return res.status(404).json({
        success: false,
        message: "No bookings found for this user",
      });
    }

    // Convert the booking documents to plain JavaScript objects
    const bookingObjects = bookings.map((booking) => booking.toObject());


    return res.status(200).json({
      success: true,
      bookings: bookingObjects,
    });

  } catch (error: any) {
    console.error("Error retrieving bookings:", error);
    return res.status(500).json({
      success: false,
      message: "Error retrieving bookings",
      error: error.message,
    });
  }
};

export default GetBooking;
