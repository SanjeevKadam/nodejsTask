import BookingData from "../model/booking.model";
import { Request, Response } from "express";
import MondayFlightData from "../model/monday.model";
import Sendmail from "./sendbookingmail.controller";

const Monday = async (req: any, res: Response) => {
  try {
    const {
      passengersNo,
      tripType,
      departdate,
      returndate,
      destination,
      departure,
      firstName,
      lastName,
      dob,
      address,
      phone,
      email,
      imageURL,
      passengers,
      price,
      checkin,
    } = req.body;

    const userEmail = req.data.email;
    let formData = {
      userEmail,
      firstName,
      lastName,
      dob,
      address,
      phone,
      email,
      imageURL,
      passengers,
      passengersNo,
      departdate,
      returndate,
      price,
      checkin,
      tripType,
      destination,
      departure,
    };

    let flight;

    if (tripType === "one-way") {
      flight = await MondayFlightData.findOne({ flightDate: departdate });

      if (!flight) {
        flight = await MondayFlightData.create({
          flightDate: departdate,
          Flight1: {
            destination: "POS",
            availableSeats: 183,
          },
          Flight2: {
            destination: "YYZ",
            availableSeats: 183,
          },
        });
      }

      const flightType =
        destination === "POS" ? flight.Flight1 : flight.Flight2;

      if (flightType.availableSeats < passengersNo) {
        return res.status(201).json({
          success: false,
          message: `Only ${flightType.availableSeats} available for the flight to ${destination}`,
          availableSeats: flightType.availableSeats,
        });
      }

      flightType.availableSeats -= passengersNo;
    } else {
      let outboundFlight = await MondayFlightData.findOne({
        flightDate: departdate,
      });
      let returnFlight = await MondayFlightData.findOne({
        flightDate: returndate,
      });

      if (!outboundFlight || !returnFlight) {
        const newFlight = await MondayFlightData.create({
          flightDate: departdate,
          Flight1: { destination: "POS", availableSeats: 183 },
          Flight2: { destination: "YYZ", availableSeats: 183 },
        });

        if (!outboundFlight) {
          outboundFlight = newFlight;
        }

        if (!returnFlight) {
          returnFlight = newFlight;
        }
      }

      const outboundSeats =
        destination === "POS" ? outboundFlight.Flight1 : outboundFlight.Flight2;
      const returnSeats =
        destination === "POS" ? returnFlight.Flight2 : returnFlight.Flight1;

      if (
        outboundSeats.availableSeats < passengersNo ||
        returnSeats.availableSeats < passengersNo
      ) {
        return res.status(201).json({
          success: false,
          message: "Not enough seats available for the selected flights",
          availableSeatsOutbound: outboundSeats.availableSeats,
          availableSeatsReturn: returnSeats.availableSeats,
        });
      }

      outboundSeats.availableSeats -= passengersNo;
      returnSeats.availableSeats -= passengersNo;
    }

    if (
      flight.Flight1.availableSeats < 0 ||
      flight.Flight2.availableSeats < 0
    ) {
      return res.status(201).json({
        success: false,
        message: "Not enough seats available for the selected flight",
      });
    }

    const bookingData = new BookingData(formData);
    await bookingData.save();
    await flight.save();


    const availableSeats =
      destination === "POS"
        ? flight.Flight1.availableSeats
        : flight.Flight2.availableSeats;
    res.status(200).json({
      success: true,
      message: "Form data saved successfully",
      refid: bookingData.id,
      availableSeats,
    });
    Sendmail(formData);
  } catch (error: any) {
    console.error("Error saving form data:", error);
    res.status(500).json({
      success: false,
      message: "Internal server error",
      error: error.message,
    });
  }
};

export default Monday;
