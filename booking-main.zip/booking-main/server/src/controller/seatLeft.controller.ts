import { Request, Response } from "express";
import MondayFlightData from "../model/monday.model";
import TuesdayFlightData from "../model/tuesday.model";
import WednesdayFlightData from "../model/wednesday.model";
import ThursdayFlightData from "../model/thursday.model";

const SeatsLeft = async (req: Request, res: Response) => {
  console.log("setas api");

  try {
    const {
      destination,
      departure,
      departdate,
      tripType,
      passengersNo,
      checkin,
      tripon,
    } = req.query;

    const parsedPassengersNo = Number(passengersNo);
    const parsedCheckin = Number(checkin);

    let seats = 0;

    let flight;
    let FlightNumber;

    switch (tripon) {
      case "monday":
        flight = await MondayFlightData.findOne({ flightDate: departdate });

        if (!flight) {
          seats = 183;
          break;
        }

        FlightNumber = destination === "POS" ? flight.Flight1 : flight.Flight2;

        seats = FlightNumber.availableSeats;

        break;
      case "tuesday":
        flight = await TuesdayFlightData.findOne({ flightDate: departdate });

        if (!flight) {
          seats = 183;
          break;
        }

        if (departure === "MBJ" && destination === "HAV") {
          FlightNumber = flight.Flight1;
        } else if (departure === "HAV" && destination === "POS") {
          FlightNumber = flight.Flight2;
        } else if (departure === "HAV" && destination === "GEO") {
          FlightNumber = flight.Flight3;
        } else if (departure === "POS" && destination === "GEO") {
          FlightNumber = flight.Flight4;
        }

        if (!FlightNumber) {
          break;
        }

        seats = FlightNumber.availableSeats;

        break;

      case "wednesday":
        flight = await WednesdayFlightData.findOne({ flightDate: departdate });

        if (!flight) {
          seats = 183;
          break;
        }

        if (departure === "GEO" && destination === "POS") {
          FlightNumber = flight.Flight1;
        } else if (departure === "POS" && destination === "HAV") {
          FlightNumber = flight.Flight2;
        } else if (departure === "HAV" && destination === "MBJ") {
          FlightNumber = flight.Flight3;
        } else if (departure === "GEO" && destination === "HAV") {
          FlightNumber = flight.Flight4;
        }

        if (!FlightNumber) {
          break;
        }

        seats = FlightNumber.availableSeats;
        break;
      case "thursday":
        flight = await ThursdayFlightData.findOne({ flightDate: departdate });

        if (!flight) {
          seats = 183;
          break;
        }

        FlightNumber =
          destination === "POS"
            ? flight.Flight1
            : destination === "GUY"
              ? flight.Flight2
              : flight.Flight3;

        if (!FlightNumber) {
          break;
        }

        seats = FlightNumber.availableSeats;
        break;
      default:
        break;
    }

    return res.status(200).json({
      success: true,
      seats: seats,
    });
  } catch (error: any) {
    console.error("Error Finding the remaning seats :", error);
    return res.status(500).json({
      success: false,
      message: "Error calculating the remaning seats",
      error: error.message,
    });
  }
};

export default SeatsLeft;
