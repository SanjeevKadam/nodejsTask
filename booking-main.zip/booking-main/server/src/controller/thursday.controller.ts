import { Request, Response } from "express";
import BookingData from "../model/booking.model";
import ThursdayFlightData from "../model/thursday.model";
import Sendmail from "./sendbookingmail.controller";

interface ThursdayRequest {
  passengersNo: number;
  tripType: string;
  departdate: string;
  returndate: string;
  destination: string;
  departure: string;
  firstName: string;
  lastName: string;
  dob: string;
  address: string;
  phone: string;
  email: string;
  imageURL: string;
  passengers: any; // Adjust the type as needed
  price: number;
  checkin: number;
}

const Thursday = async (
  req: any,
  res: Response,
) => {
  try {
    const {
      passengersNo,
      tripType,
      departdate,
      returndate,
      destination,
      departure,
      firstName,
      lastName,
      dob,
      address,
      phone,
      email,
      imageURL,
      passengers,
      price,
      checkin,
    } = req.body;

    const userEmail = req.data.email;
    let formData = {
      userEmail,
      firstName,
      lastName,
      dob,
      address,
      phone,
      email,
      imageURL,
      passengers,
      passengersNo,
      departdate,
      returndate,
      price,
      checkin,
      tripType,
      destination,
      departure,
    };

    if (tripType === "one-way") {
      let flight;

      switch (destination) {
        case "POS":
        case "GUY":
        case "MIA":
          flight = await ThursdayFlightData.findOne({ flightDate: departdate });

          if (!flight) {
            flight = await ThursdayFlightData.create({
              flightDate: departdate,
              Flight1: { destination: "POS", availableSeats: 183 },
              Flight2: { destination: "GUY", availableSeats: 183 },
              Flight3: { destination: "MIA", availableSeats: 183 },
            });
          }

          const flightKey =
            destination === "POS"
              ? "Flight1"
              : destination === "GUY"
                ? "Flight2"
                : "Flight3";

          if (flight[flightKey]!.availableSeats < passengersNo) {
            return res.status(201).json({
              success: false,
              message: `Only ${flight[flightKey]!.availableSeats
                } available for the flight to ${destination}`,
              availableSeats: flight[flightKey]!.availableSeats,
            });
          }

          flight[flightKey]!.availableSeats -= passengersNo;
          break;

        default:
          return res.status(201).json({
            success: false,
            message: "Invalid destination",
          });
      }

      const bookingData = new BookingData(formData);
      await bookingData.save();
      await flight.save();

      res.status(200).json({
        success: true,
        message: "Form data saved successfully",
        refid: bookingData.id,
      });
      Sendmail(formData);
    }
  } catch (error: any) {
    console.error("Error saving form data:", error);
    res.status(500).json({
      success: false,
      message: "Internal server error",
      error: error.message,
    });
  }
};

export default Thursday;
