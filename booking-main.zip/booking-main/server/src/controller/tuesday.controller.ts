import { Request, Response } from "express";
import BookingData from "../model/booking.model";
import TuesdayFlightData from "../model/tuesday.model";
import Sendmail from "./sendbookingmail.controller";

interface TuesdayRequest {
  passengersNo: number;
  tripType: string;
  departdate: string;
  returndate: string;
  destination: string;
  departure: string;
  firstName: string;
  lastName: string;
  dob: string;
  address: string;
  phone: string;
  email: string;
  imageURL: string;
  passengers: any; // Adjust the type as needed
  price: number;
  checkin: number;
}

const Tuesday = async (req: any, res: Response) => {
  try {
    const {
      passengersNo,
      tripType,
      departdate,
      returndate,
      destination,
      departure,
      firstName,
      lastName,
      dob,
      address,
      phone,
      email,
      imageURL,
      passengers,
      price,
      checkin,
      tripon,
    } = req.body;

    const userEmail = req.data.email;
    let formData = {
      userEmail,
      tripon,
      firstName,
      lastName,
      dob,
      address,
      phone,
      email,
      imageURL,
      passengers,
      passengersNo,
      departdate,
      returndate,
      price,
      checkin,
      tripType,
      destination,
      departure,
    };

    if (tripType === "one-way") {
      let flight;

      switch (destination) {
        case "HAV":
        case "POS":
        case "GEO":
          // case "JAM":
          // case "GUY":
          // case "MIA":
          flight = await TuesdayFlightData.findOne({ flightDate: departdate });

          if (!flight) {
            flight = await TuesdayFlightData.create({
              flightDate: departdate,
              Flight1: {
                destination: "HAV",
                departure: "MBJ",
                availableSeats: 183,
              },
              Flight2: {
                destination: "POS",
                departure: "HAV",
                availableSeats: 183,
              },
              Flight3: {
                destination: "GEO",
                departure: "POS",
                availableSeats: 183,
              },
              Flight4: {
                destination: "GEO",
                departure: "HAV",
                availableSeats: 183,
              },
              // Flight3: { destination: "GUY", availableSeats: 183 },
              // Flight4: { destination: "MIA", availableSeats: 183 },
            });
          }


          break;

        default:
          return res.status(201).json({
            success: false,
            message: "Invalid destination",
          });
      }

      await flight.save();

      const bookingData = new BookingData(formData);
      await bookingData.save();
      res.status(200).json({
        success: true,
        message: "Form data saved successfully",
        refid: bookingData.id,
      });
    }
  } catch (error: any) {
    console.error("Error saving form data:", error);
    res.status(500).json({
      success: false,
      message: "Internal server error",
      error: error.message,
    });
  }
};

export default Tuesday;
