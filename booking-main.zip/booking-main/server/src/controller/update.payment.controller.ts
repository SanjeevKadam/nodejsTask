import { Request, Response } from "express";
import { Document, Model } from "mongoose";
import BookingData from "../model/booking.model";
import Sendmail from "./sendbookingmail.controller";
import TuesdayFlightData from "../model/tuesday.model";
import WednesdayFlightData from "../model/wednesday.model";
import mongoose from "mongoose";

export const UpdateBookingPayment = async (req: Request, res: Response) => {
  console.log("Get booking ");
  const session = await mongoose.startSession();

  try {
    session.startTransaction();
    const refid = req.body.refid;
    // const payid = req.body.payid;

    // if (!refid) {
    //   await session.abortTransaction();
    //   return res.status(400).json({
    //     success: false,
    //     message: "Refid is missing in the request body",
    //   });
    // }

    const booking: any = await BookingData.findById(refid);

    const {
      passengersNo,
      tripType,
      tripon,
      departdate,
      returndate,
      userEmail,
      destination,
      departure,
      firstName,
      lastName,
      dob,
      address,
      phone,
      email,
      imageURL,
      passengers,
      price,
      checkin,
    } = booking;

    let formData = {
      userEmail,
      tripon,
      firstName,
      lastName,
      dob,
      address,
      phone,
      email,
      imageURL,
      passengers,
      passengersNo,
      departdate,
      returndate,
      price,
      checkin,
      tripType,
      destination,
      departure,
    };

    if (!booking) {

      await session.abortTransaction();

      return res.status(404).json({
        success: false,
        message: "Booking not found",
      });
    }

    booking.isPaid = true;
    // booking.status = "Paid"
    // booking.payid = payid;


    await booking.save();

    if (tripon === "tuesday") {

      try {
        const flight: Document<any, any, { flightDate?: Date, Flight1?: { destination: string; departure: string; availableSeats: number }, Flight2?: { destination: string; departure: string; availableSeats: number }, Flight3?: { destination: string; departure: string; availableSeats: number }, Flight4?: { destination: string; departure: string; availableSeats: number } }> | null = await TuesdayFlightData.findOne({ flightDate: departdate });

        if (!flight) {
          await session.abortTransaction();
          return res.status(500).json({
            success: false,
            message: "Flight not found",
          });
        }

        let flightKey: "Flight1" | "Flight2" | "Flight3" | "Flight4";

        // Determine flight key based on departure and destination
        if (departure === "MBJ" && destination === "HAV") {
          flightKey = "Flight1";
        } else if (departure === "HAV" && destination === "POS") {
          flightKey = "Flight2";
        } else if (departure === "HAV" && destination === "GEO") {
          flightKey = "Flight3";
        } else if (departure === "POS" && destination === "GEO") {
          flightKey = "Flight4";
        } else {
          // Handle the case where there's no matching flight
          await session.abortTransaction();
          return res.status(500).json({
            success: false,
            message: "No matching flight found for the given departure and destination.",
          });
        }

        const availableSeats = flight.get(flightKey + ".availableSeats");

        if (availableSeats < passengersNo) {
          await session.abortTransaction();
          return res.status(201).json({
            success: false,
            message: `Only ${availableSeats} available for the flight to ${destination}`,
            availableSeats: availableSeats,
          });
        }

        if (flightKey === "Flight2" || flightKey === "Flight3") {
          const flight2AvailableSeats = flight.get("Flight2.availableSeats");
          const flight3AvailableSeats = flight.get("Flight3.availableSeats");
          const lesserAvailableSeats = Math.min(flight2AvailableSeats, flight3AvailableSeats);

          await flight.updateOne({
            $set: {
              "Flight4.availableSeats": lesserAvailableSeats
            }
          });
        }
        await flight.updateOne({ $inc: { [`${flightKey}.availableSeats`]: -passengersNo } });


        return res.status(200).json({
          success: true,
          message: `Flight updated successfully`,
          availableSeats: availableSeats - passengersNo,
        });
      } catch (error) {
        console.error("Error occurred:", error);
        await session.abortTransaction();
        return res.status(500).json({
          success: false,
          message: "Internal Server Error",
        });
      }


    } else if (tripon === "wednesday") {
      try {
        const flight: Document<any, any, { flightDate?: Date, Flight1?: { destination: string; departure: string; availableSeats: number }, Flight2?: { destination: string; departure: string; availableSeats: number }, Flight3?: { destination: string; departure: string; availableSeats: number }, Flight4?: { destination: string; departure: string; availableSeats: number } }> | null = await WednesdayFlightData.findOne({ flightDate: departdate });

        if (!flight) {
          await session.abortTransaction();
          return res.status(500).json({
            success: false,
            message: "Flight not found",
          });
        }

        let flightKey: "Flight1" | "Flight2" | "Flight3" | "Flight4";

        // Determine flight key based on departure and destination
        if (departure === "GEO" && destination === "POS") {
          flightKey = "Flight1";
        } else if (departure === "POS" && destination === "HAV") {
          flightKey = "Flight2";
        } else if (departure === "HAV" && destination === "MBJ") {
          flightKey = "Flight3";
        } else if (departure === "GEO" && destination === "HAV") {
          flightKey = "Flight4";
        } else {
          // Handle the case where there's no matching flight
          await session.abortTransaction();
          return res.status(500).json({
            success: false,
            message: "No matching flight found for the given departure and destination.",
          });
        }

        const availableSeats = flight.get(flightKey + ".availableSeats");

        if (availableSeats < passengersNo) {
          await session.abortTransaction();
          return res.status(201).json({
            success: false,
            message: `Only ${availableSeats} available for the flight to ${destination}`,
            availableSeats: availableSeats,
          });
        }

        if (flightKey === "Flight2" || flightKey === "Flight1") {
          const flight2AvailableSeats = flight.get("Flight2.availableSeats");
          const flight1AvailableSeats = flight.get("Flight1.availableSeats");
          const lesserAvailableSeats = Math.min(flight2AvailableSeats, flight1AvailableSeats);

          await flight.updateOne({
            $set: {
              "Flight4.availableSeats": lesserAvailableSeats
            }
          });
        }
        await flight.updateOne({ $inc: { [`${flightKey}.availableSeats`]: -passengersNo } });


        return res.status(200).json({
          success: true,
          message: `Flight updated successfully`,
          availableSeats: availableSeats - passengersNo,
        });
      } catch (error) {
        console.error("Error occurred:", error);
        await session.abortTransaction();
        return res.status(500).json({
          success: false,
          message: "Internal Server Error",
        });
      }
    }
    res.status(200).json({
      success: true,
    });

    Sendmail(formData);
  } catch (error: any) {
    console.error("Error updating the payment", error);
    await session.abortTransaction();
    return res.status(500).json({
      success: false,
      message: "Error updating the payment",
      error: error.message,
    });
  }
};
