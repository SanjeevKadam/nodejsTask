import { Request, Response } from "express";
import BookingData from "../model/booking.model";
import WednesdayFlightData from "../model/wednesday.model";
import { FormDataType } from "../types";
import Sendmail from "./sendbookingmail.controller";

const Wednesday = async (req: any, res: Response) => {
  try {
    const {
      passengersNo,
      tripType,
      departdate,
      returndate,
      destination,
      departure,
      firstName,
      lastName,
      dob,
      address,
      phone,
      email,
      imageURL,
      passengers,
      price,
      checkin,
      tripon,
    } = req.body;

    const userEmail = req.data.email;
    let formData = {
      userEmail,
      tripon,
      firstName,
      lastName,
      dob,
      address,
      phone,
      email,
      imageURL,
      passengers,
      passengersNo,
      departdate,
      returndate,
      price,
      checkin,
      tripType,
      destination,
      departure,
    };

    if (tripType === "one-way") {
      let flight;

      switch (destination) {
        case "POS":
        case "HAV":
        case "MBJ":
          // case "JAM":
          // case "GUY":
          // case "MIA":
          flight = await WednesdayFlightData.findOne({ flightDate: departdate });

          if (!flight) {
            flight = await WednesdayFlightData.create({
              flightDate: departdate,
              Flight1: {
                destination: "POS",
                departure: "GEO",
                availableSeats: 183,
              },
              Flight2: {
                destination: "HAV",
                departure: "POS",
                availableSeats: 183,
              },
              Flight3: {
                destination: "MBJ",
                departure: "HAV",
                availableSeats: 183,
              },
              Flight4: {
                destination: "HAV",
                departure: "GEO",
                availableSeats: 183,
              },
            });
          }


          break;

        default:
          return res.status(201).json({
            success: false,
            message: "Invalid destination",
          });
      }

      await flight.save();

      const bookingData = new BookingData(formData);
      await bookingData.save();
      res.status(200).json({
        success: true,
        message: "Form data saved successfully",
        refid: bookingData.id,
      });
    }
  } catch (error: any) {
    console.error("Error saving form data:", error);
    res.status(500).json({
      success: false,
      message: "Internal server error",
      error: error.message,
    });
  }
};

export default Wednesday;
