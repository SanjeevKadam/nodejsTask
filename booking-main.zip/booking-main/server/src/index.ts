// import nodemailer from "nodemailer";
require("dotenv").config();
import express from "express";
import bodyParser from "body-parser";
import cors from "cors";
import connectDB from "./db/connect";
import router, { authenticateJwt } from "./routes/route";
// import adminRouter from "./routes/adminroute";
const { secretSchema, validate } = require('./validater');

const stripe = require("stripe")(
  process.env.STRIPE_SECRET_KEY
);

const PORT = process.env.PORT;

const app = express();
app.use(cors());

app.use(bodyParser.json());

connectDB();
app.get("/secret", authenticateJwt, validate(secretSchema), async (req, res) => {
  const { price } = req.query as any;
  const amount = price * 100;
  const intent = await stripe.paymentIntents.create({
    amount: amount,
    // currency: "inr",
    currency: "usd",
    automatic_payment_methods: {
      enabled: true,
    },
  });
  // console.log(intent)

  res.json({ client_secret: intent.client_secret, payid: intent.id });
});

app.use(router);
// app.use(adminRouter);

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
