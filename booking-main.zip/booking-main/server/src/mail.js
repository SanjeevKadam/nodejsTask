const nodemailer = require('nodemailer');
const fs = require('fs');
const PASSWORD = 'cplmrwzygtwxgvxy';
const User = 'relayio@umojaairways.com';
const EmailFrom = 'no-reply@umojaairways.com';

// Create a transporter using SMTP details
const transporter = nodemailer.createTransport({
  host: 'smtp.office365.com',
  port: 587,
  secure: false, // Set to true if using port 465 with SSL
  auth: {
    user: User,
    pass: PASSWORD,
  },
  tls: {
    ciphers: 'SSLv3',
  },
});
const data = {
  userEmail: 'vipin.chaudhary@nditsolutions.com',
  firstName: 'vipin',
  lastName: 'chaudhary',
  dob: {
    $date: '2002-02-15T13:47:53.000Z',
  },
  address: 'VAC/137TH E Avenue S, Sun Village, CA 93543, USA',
  email: 'Vipintest@gmail.com',
  phone: '+918178225806',
  imageURL: '',
  passengers: [],
  passengersNo: 1,
  departdate: '2024-03-04T18:30:00.000Z',
  returndate: null,
  price: 680,
  tripon: 'tuesday',
  checkin: 1,
  isPaid: true,
  tripType: 'one-way',
  destination: 'GEO',
  departure: 'HAV',
  __v: 0,
};
const departureDate = new Date(data.departdate);
const formattedDepartureDate = departureDate.toLocaleDateString('en-US', {
  year: 'numeric',
  month: 'long',
  day: 'numeric',
  // hour: 'numeric',
  // minute: 'numeric',
  // hour12: true,
});

const html = ` 
`;

const mailOptions = {
  from: EmailFrom,
  to: 'vipin.chaudhary@nditsolutions.com', // Replace with the recipient's email address
  subject: 'Subject of the email',
  html: html, // Pass the HTML content read from the file
};

// Send the email

transporter.sendMail(mailOptions, (error, info) => {
  if (error) {
    return console.error('Error:', error);
  }
  {
    console.log('Email sent:', info.response);
  }
});

