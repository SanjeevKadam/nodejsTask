import mongoose from "mongoose"; // Create a mongoose schema for the form data

const bookingDataSchema = new mongoose.Schema(
  {
    userEmail: String,
    firstName: String,
    lastName: String,
    dob: Date,
    address: String,
    email: String,
    phone: String,
    imageURL: String,
    passengers: Array,
    passengersNo: Number,
    departdate: Date,
    returndate: Date,
    price: Number,
    tripon: String,
    checkin: Number,
    isPaid: { type: Boolean, default: false },
    tripType: {
      type: String,
      enum: ["one-way", "round-trip"],
    },
    destination: {
      type: String,
    },
    departure: {
      type: String,
    },
  },
  { collection: "booking" },
);

const BookingData = mongoose.model("BookingData", bookingDataSchema);
export default BookingData;
