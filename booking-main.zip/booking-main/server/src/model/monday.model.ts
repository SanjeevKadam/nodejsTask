const mongoose = require("mongoose");

const flightDataSchema = new mongoose.Schema(
  {
    flightDate: Date,
    Flight1: {
      destination: {
        type: String,
        default: "POS",
      },
      availableSeats: {
        type: Number,
        default: 183,
      },
    },
    Flight2: {
      destination: {
        type: String,
        default: "YYZ",
      },
      availableSeats: {
        type: Number,
        default: 183,
      },
    },
  },
  { collection: "monday_flight" },
);

const MondayFlightData = mongoose.model("MondayFlightData", flightDataSchema);
export default MondayFlightData;
