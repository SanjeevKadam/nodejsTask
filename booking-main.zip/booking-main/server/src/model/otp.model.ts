import { string } from 'joi';
import mongoose, { Schema } from 'mongoose';

const tokenSchema = new Schema({
  // _userId: { type: Schema.Types.ObjectId, required: true, ref: 'user' },
  //

  email: { type: String, required: true },
  otp: { type: String, required: true },
  createdAt: { type: Date, expires: '5m', default: Date.now } // TTL index expires documents after 1 minute

}, { timestamps: true },);

const OTP = mongoose.model('otp', tokenSchema);
export default OTP;
