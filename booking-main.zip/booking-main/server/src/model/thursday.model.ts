import mongoose from "mongoose"; // Create a mongoose schema for the form data

const flightDataSchema = new mongoose.Schema(
  {
    flightDate: Date,
    Flight1: {
      destination: {
        type: String,
        default: "POS", // Default value for destination
      },
      availableSeats: {
        type: Number,
        default: 183, // Default value for availableSeats
      },
    },
    Flight2: {
      destination: {
        type: String,
        default: "GUY", // Default value for destination
      },
      availableSeats: {
        type: Number,
        default: 183, // Default value for availableSeats
      },
    },
    Flight3: {
      destination: {
        type: String,
        default: "MIA", // Default value for destination
      },
      availableSeats: {
        type: Number,
        default: 183, // Default value for availableSeats
      },
    },
  },
  { collection: "thursday_flight" },
);

const ThursdayFlightData = mongoose.model(
  "ThursdayFlightData ",
  flightDataSchema,
);
export default ThursdayFlightData;
