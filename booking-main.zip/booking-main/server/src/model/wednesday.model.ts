import mongoose from "mongoose"; // Create a mongoose schema for the form data

const flightDataSchema = new mongoose.Schema(
  {
    flightDate: Date,
    Flight1: {
      destination: {
        type: String,
        default: "POS", // Default value for destination
      },
      departure: {
        type: String,
        default: "GEO", // Default value for destination
      },
      availableSeats: {
        type: Number,
        default: 183, // Default value for availableSeats
      },
    },
    Flight2: {
      destination: {
        type: String,
        default: "HAV", // Default value for destination
      },
      departure: {
        type: String,
        default: "POS", // Default value for destination
      },
      availableSeats: {
        type: Number,
        default: 183, // Default value for availableSeats
      },
    },
    Flight3: {
      destination: {
        type: String,
        default: "MBJ", // Default value for destination
      },
      departure: {
        type: String,
        default: "HAV", // Default value for destination
      },
      availableSeats: {
        type: Number,
        default: 183, // Default value for availableSeats
      },
    },
    Flight4: {
      destination: {
        type: String,
        default: "HAV", // Default value for destination
      },
      departure: {
        type: String,
        default: "GEO", // Default value for destination
      },
      availableSeats: {
        type: Number,
        default: 183, // Default value for availableSeats
      },
    },
  },
  { collection: "wednesday_flight" },
);

const WednesdayFlightData = mongoose.model(
  "WednesdayFlightData ",
  flightDataSchema,
);
export default WednesdayFlightData;
