import express, { NextFunction, Request, Response } from "express";
import jwt from "jsonwebtoken";

import * as crypto from 'crypto';
import nodemailer from "nodemailer"
import User from "../model/user.model";
import Monday from "../controller/monday.controller";
import Thursday from "../controller/thursday.controller";
import Tuesday from "../controller/tuesday.controller";
import Wednesday from "../controller/wednesday.controller";
import MondayFlightData from "../model/monday.model";
import SeatsLeft from "../controller/seatLeft.controller";
import GetBooking from "../controller/getbooking.controller";
import Bcrypt from 'bcrypt';
import OTP from "../model/otp.model";
import { responseEncoding } from "axios";
import GetBookingFromId from "../controller/getbooking.controller";
import { UpdateBookingPayment } from "../controller/update.payment.controller";
import getPrice from "../controller/Getprice.controller";
// import { transporter } from "../mail";
const router = express.Router();

const PASSWORD = 'cplmrwzygtwxgvxy';
const user = 'relayio@umojaairways.com'
const SECRET = "P@ssw0rd!Secure123"

router.get("/", (_req: Request, res: Response) => {
  console.log("GET request received");
  res.send("Welcome to the flight booking system Version1!");
});

export const authenticateJwt = (req: any, res: Response, next: NextFunction) => {
  const authHeader = req.headers.authorization;
  if (authHeader) {
    const token = authHeader.split(' ')[1];
    jwt.verify(token, SECRET, (err: any, decoded: any) => {
      if (err) {
        return res.sendStatus(403);
      }
      req.data = decoded;
      next();
    });
  } else {
    res.sendStatus(401);
  }
};

router.get('/confirm', authenticateJwt, async (req: any, res: Response) => {
  console.log(req.data.email)
  res.status(200).send({
    email: req.data.email
  })

})
const generateOTP = () => {
  const characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let otp = '';
  for (let i = 0; i < 6; i++) {
    otp += characters.charAt(Math.floor(Math.random() * characters.length));
  }
  return otp;
};

// Endpoint for sending OTP
router.post('/sendOTP', async (req, res) => {
  const { email } = req.body;

  try {
    // Check if the user exists
    let user = await User.findOne({ email });

    if (!user) {
      // Create a new user if not exists
      user = new User({ email });
      await user.save();
    }

    // Generate and save OTP
    const otpValue = generateOTP();
    await OTP.findOneAndUpdate({ email }, { email, otp: otpValue }, { upsert: true });

    const transporter = nodemailer.createTransport({
      host: 'smtp.office365.com',
      port: 587,
      secure: false,
      auth: {
        user: process.env.SMTP_USER || user,
        pass: process.env.SMTP_PASSWORD || PASSWORD,
      },
      tls: {
        ciphers: 'SSLv3',
      },
    } as any);

    // Send OTP via email
    const mailOptions = {
      from: 'no-reply@umojaairways.com',
      to: email,
      subject: 'OTP for Login',
      html: ` <!DOCTYPE html>
 <html lang="en">
 <head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <title>Email Verification</title>
 <style>
   /* Style your email content here */
   body {
     font-family: Arial, sans-serif;
     background-color: #f4f4f4;
     margin: 0;
     padding: 0;
   }
   .container {
     max-width: 600px;
     margin: 0 auto;
     padding: 20px;
     background-color: #fff;
     border-radius: 10px;
     box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
   }
   h1 {
     color: #333;
     text-align: center;
   }
   p {
     color: #666;
     line-height: 1.6;
   }
   .button {
     display: inline-block;
     background-color: #007bff;
     color: #fff;
     text-decoration: none;
     padding: 10px 20px;
     border-radius: 5px;
     margin-top: 20px;
   }
 </style>
 </head>
 <body>
   <div class="container">
  <h1>Email Verification</h1>
  <p>Hello,</p>

  <p>Thank you for signing up! Please use the following OTP for email verification:</p>
  <p><strong>Your OTP:</strong> <span style="font-size: 1.2em; font-weight: bold; color: #3366cc;">${otpValue}</span></p>

  <p>This OTP is valid for a short period, so make sure to use it promptly.</p>

  <p>If you did not request this verification, please ignore this email.</p>

  <p>Thank you!</p>
   </div>
 </body>
 </html>
 `
      ,
    };

    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        return res.status(500).json({ error: true, msg: 'Failed to send verification otp.', err: error.message });
      }
      return res.status(200).json({ success: true, msg: 'A verification otp has been sent. ' });
    });

    // res.status(200).json({ message: 'OTP sent successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// Endpoint for verifying OTP and generating JWT
router.post('/verifyOTP', async (req, res) => {
  const { email, otp } = req.body;

  try {
    // Find OTP
    const otpRecord = await OTP.findOne({ email, otp }).exec();
    if (!otpRecord) { // 5min experire 
      return res.status(401).json({ error: 'Invalid OTP or expired' });
    }

    // Generate JWT token
    const token = jwt.sign({ email: email }, SECRET, {
      expiresIn: '6h', // You can adjust the expiration time as needed
    });

    res.status(200).json({ token });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

router.get("/api/ticket-price", authenticateJwt, getPrice);
router.get("/api/seats-left", authenticateJwt, SeatsLeft);
router.get("/api/get-booking-from-ids", authenticateJwt, GetBookingFromId);
router.get("/api/get-booking", authenticateJwt, GetBookingFromId);
router.post("/api/update-payment", authenticateJwt, UpdateBookingPayment);
router.post("/api/bookingFormData/monday", authenticateJwt, Monday);
router.post("/api/bookingFormData/tuesday", authenticateJwt, Tuesday);
router.post("/api/bookingFormData/wednesday", authenticateJwt, Wednesday);
router.post("/api/bookingFormData/thursday", authenticateJwt, Thursday);

export default router;
