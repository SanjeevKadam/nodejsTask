export interface FormDataType {
  firstName: string;
  lastName: string;
  dob: string;
  address: string;
  phone: string;
  email: string;
  imageURL: string;
  passengers: string;
  passengersNo: number;
  departdate: string;
  returndate: string;
  price: number;
  checkin: boolean;
  tripType: string;
  destination: string;
  departure: string;
}
