import { z } from 'zod';
import { Request, Response, NextFunction } from 'express';

const secretSchema = z.object({
  query: z.object({
    // email should be valid and non-empty
    price: z.string().min(2)
  }),
});

const validate = (schema: any) => (req: Request, res: Response, next: NextFunction) => {
  try {
    schema.parse({
      body: req.body,
      query: req.query,
      params: req.params,
    });

    next();
  } catch (err) {
    return res.status(400).send(err);
  }
};

module.exports = { secretSchema, validate };
